import api from './api';

export const userService = {
  getUsers: async (skip = 0, limit = 100) => {
    const response = await api.get('/users', { params: { skip, limit } });
    return response.data;
  },

  getUserById: async (id) => {
    const response = await api.get(`/users/${id}`);
    return response.data;
  },

  createUser: async (userData) => {
    const response = await api.post('/users', userData);
    return response.data;
  },

  updateUser: async (id, userData) => {
    const response = await api.put(`/users/${id}`, userData);
    return response.data;
  },

  assignRoles: async (userId, roleIds) => {
    const response = await api.post(`/users/${userId}/roles`, { role_ids: roleIds });
    return response.data;
  },

  getRoles: async () => {
    const response = await api.get('/users/access/roles');
    return response.data;
  },

  getPermissions: async () => {
    const response = await api.get('/users/access/permissions');
    return response.data;
  },
};
