import api from './api';

export const auditService = {
  getLogs: async (params = {}) => {
    const response = await api.get('/audit/logs', { params });
    return response.data;
  },

  getMyLogs: async (limit = 50) => {
    const response = await api.get('/audit/my-logs', { params: { limit } });
    return response.data;
  },
};
