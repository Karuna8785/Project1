import axios from 'axios';
import { tokenStorage } from '../utils/tokenStorage';

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:8000/api/v1';

const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
  timeout: 15000,
});

// Request Interceptor: Attach JWT Bearer token
api.interceptors.request.use(
  (config) => {
    const token = tokenStorage.getToken();
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// Response Interceptor: Extract error messages and handle 401
api.interceptors.response.use(
  (response) => response,
  (error) => {
    const status = error.response ? error.response.status : null;
    
    // Format error message cleanly
    let message = 'An unexpected error occurred. Please try again.';
    if (error.response && error.response.data) {
      const data = error.response.data;
      if (typeof data.detail === 'string') {
        message = data.detail;
      } else if (Array.isArray(data.detail) && data.detail.length > 0) {
        message = data.detail.map((err) => err.msg || err.message).join(', ');
      } else if (data.message) {
        message = data.message;
      }
    } else if (error.message === 'Network Error') {
      message = 'Backend API server unreachable. Please make sure FastAPI backend is running on port 8000.';
    }

    error.extractedMessage = message;

    if (status === 401 && !error.config.url.includes('/auth/login')) {
      tokenStorage.clearAll();
      // Optional: Dispatch custom event or redirect
      if (window.location.pathname !== '/login') {
        window.location.href = '/login';
      }
    }

    return Promise.reject(error);
  }
);

export default api;
