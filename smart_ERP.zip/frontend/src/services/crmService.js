import api from './api';

export const crmService = {
  // Overview
  getOverview: async () => {
    const response = await api.get('/crm/overview');
    return response.data;
  },

  getCustomerStats: async () => {
    const response = await api.get('/crm/stats/customers');
    return response.data;
  },

  getLeadStats: async () => {
    const response = await api.get('/crm/stats/leads');
    return response.data;
  },

  // Customers
  getCustomers: async (params = {}) => {
    const response = await api.get('/crm/customers', { params });
    return response.data;
  },

  getCustomerById: async (id) => {
    const response = await api.get(`/crm/customers/${id}`);
    return response.data;
  },

  createCustomer: async (customerData) => {
    const response = await api.post('/crm/customers', customerData);
    return response.data;
  },

  updateCustomer: async (id, customerData) => {
    const response = await api.put(`/crm/customers/${id}`, customerData);
    return response.data;
  },

  deleteCustomer: async (id) => {
    const response = await api.delete(`/crm/customers/${id}`);
    return response.data;
  },

  getCustomerTimeline: async (customerId) => {
    const response = await api.get(`/crm/customers/${customerId}/timeline`);
    return response.data;
  },

  // Leads
  getLeads: async (params = {}) => {
    const response = await api.get('/crm/leads', { params });
    return response.data;
  },

  getLeadById: async (id) => {
    const response = await api.get(`/crm/leads/${id}`);
    return response.data;
  },

  createLead: async (leadData) => {
    const response = await api.post('/crm/leads', leadData);
    return response.data;
  },

  updateLead: async (id, leadData) => {
    const response = await api.put(`/crm/leads/${id}`, leadData);
    return response.data;
  },

  deleteLead: async (id) => {
    const response = await api.delete(`/crm/leads/${id}`);
    return response.data;
  },

  convertLead: async (id, convertData = {}) => {
    const response = await api.post(`/crm/leads/${id}/convert`, convertData);
    return response.data;
  },

  getLeadTimeline: async (leadId) => {
    const response = await api.get(`/crm/leads/${leadId}/timeline`);
    return response.data;
  },

  // Interactions & Follow-ups
  getInteractions: async (limit = 20) => {
    const response = await api.get('/crm/interactions', { params: { limit } });
    return response.data;
  },

  logInteraction: async (interactionData) => {
    const response = await api.post('/crm/interactions', interactionData);
    return response.data;
  },

  getUpcomingFollowups: async (limit = 20) => {
    const response = await api.get('/crm/followups', { params: { limit } });
    return response.data;
  },
};
