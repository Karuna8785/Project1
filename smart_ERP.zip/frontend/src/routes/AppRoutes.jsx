import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { ProtectedRoute } from './ProtectedRoute';
import { Layout } from '../components/layout/Layout';

// Auth Pages
import { Login } from '../pages/auth/Login';
import { Register } from '../pages/auth/Register';

// Core Pages
import { Dashboard } from '../pages/dashboard/Dashboard';
import { Profile } from '../pages/profile/Profile';

// Member 3 CRM Pages
import { CRMOverview } from '../pages/crm/CRMOverview';
import { CustomersPage } from '../pages/crm/CustomersPage';
import { CustomerDetailPage } from '../pages/crm/CustomerDetailPage';
import { LeadsPage } from '../pages/crm/LeadsPage';
import { CustomerHistoryPage } from '../pages/crm/CustomerHistoryPage';

// Admin Pages
import { UsersPage } from '../pages/admin/UsersPage';
import { AuditLogsPage } from '../pages/admin/AuditLogsPage';

// Placeholders for Upcoming Modules
import { ModulePlaceholder } from '../pages/placeholders/ModulePlaceholder';

export const AppRoutes = () => {
  return (
    <Routes>
      {/* Public Auth Routes */}
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />

      {/* Protected ERP Dashboard & Modules */}
      <Route
        path="/"
        element={
          <ProtectedRoute>
            <Layout />
          </ProtectedRoute>
        }
      >
        <Route index element={<Navigate to="/dashboard" replace />} />
        <Route path="dashboard" element={<Dashboard />} />
        <Route path="profile" element={<Profile />} />

        {/* Member 3 — CRM Routes */}
        <Route path="crm" element={<CRMOverview />} />
        <Route path="crm/customers" element={<CustomersPage />} />
        <Route path="crm/customers/:id" element={<CustomerDetailPage />} />
        <Route path="crm/leads" element={<LeadsPage />} />
        <Route path="crm/history" element={<CustomerHistoryPage />} />

        {/* Admin & Security Routes */}
        <Route
          path="users"
          element={
            <ProtectedRoute allowedRoles={['ADMIN', 'MANAGER']}>
              <UsersPage />
            </ProtectedRoute>
          }
        />
        <Route
          path="audit-logs"
          element={
            <ProtectedRoute allowedRoles={['ADMIN', 'MANAGER']}>
              <AuditLogsPage />
            </ProtectedRoute>
          }
        />

        {/* Future Module Placeholders */}
        <Route path="hr" element={<ModulePlaceholder />} />
        <Route path="inventory" element={<ModulePlaceholder />} />
        <Route path="sales" element={<ModulePlaceholder />} />
        <Route path="procurement" element={<ModulePlaceholder />} />
        <Route path="finance" element={<ModulePlaceholder />} />
        <Route path="reports" element={<ModulePlaceholder />} />
      </Route>

      {/* Fallback */}
      <Route path="*" element={<Navigate to="/dashboard" replace />} />
    </Routes>
  );
};
