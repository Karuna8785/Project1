import React from 'react';
import { NavLink, Link, useLocation } from 'react-router-dom';
import {
  LayoutDashboard,
  ShieldAlert,
  UserCheck,
  TrendingUp,
  Building2,
  Target,
  History,
  Users,
  Package,
  ShoppingBag,
  Truck,
  Landmark,
  BarChart3,
  ShieldCheck,
  Sparkles,
  ChevronRight,
  LogOut,
  User as UserIcon,
} from 'lucide-react';
import { useAuth } from '../../hooks/useAuth';
import { MODULE_NAVIGATION } from '../../utils/constants';

const iconMap = {
  LayoutDashboard,
  ShieldAlert,
  UserCheck,
  TrendingUp,
  Building2,
  Target,
  History,
  Users,
  Package,
  ShoppingBag,
  Truck,
  Landmark,
  BarChart3,
};

export const Sidebar = ({ isOpen, onClose }) => {
  const { user, logout, hasRole } = useAuth();
  const location = useLocation();

  return (
    <>
      {/* Mobile overlay */}
      {isOpen && (
        <div
          className="fixed inset-0 z-40 bg-slate-900/60 backdrop-blur-sm lg:hidden"
          onClick={onClose}
        />
      )}

      <aside
        className={`fixed top-0 bottom-0 left-0 z-40 w-72 bg-slate-900 text-slate-300 flex flex-col border-r border-slate-800 transition-transform duration-300 ease-in-out lg:translate-x-0 ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        {/* Brand Header */}
        <div className="h-16 flex items-center justify-between px-6 border-b border-slate-800/80 bg-slate-950/40">
          <Link to="/dashboard" className="flex items-center gap-3 group">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-blue-600 to-indigo-500 flex items-center justify-center text-white shadow-md shadow-blue-500/20 group-hover:scale-105 transition-transform">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-bold text-base text-white tracking-tight">SmartERP</span>
                <span className="text-[10px] uppercase font-bold tracking-widest px-1.5 py-0.5 rounded bg-blue-500/20 text-blue-400 border border-blue-500/30">
                  Enterprise
                </span>
              </div>
              <p className="text-[11px] text-slate-400 font-medium">Modular Architecture</p>
            </div>
          </Link>
        </div>

        {/* Modules Nav */}
        <div className="flex-1 overflow-y-auto px-4 py-4 space-y-6">
          {MODULE_NAVIGATION.map((group, groupIdx) => {
            // Filter out items that require roles user does not have
            const visibleItems = group.items.filter((item) => {
              if (item.roleRequired) {
                return hasRole(item.roleRequired);
              }
              return true;
            });

            if (visibleItems.length === 0) return null;

            return (
              <div key={groupIdx} className="space-y-1.5">
                <div className="px-3 text-[11px] font-bold uppercase tracking-wider text-slate-400 flex items-center justify-between">
                  <span>{group.category}</span>
                  {group.category.includes('Member 3') && (
                    <span className="inline-flex items-center gap-1 text-[10px] text-emerald-400 font-normal">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                      Live
                    </span>
                  )}
                </div>

                <div className="space-y-0.5">
                  {visibleItems.map((item) => {
                    const Icon = iconMap[item.icon] || LayoutDashboard;
                    const isActive = location.pathname === item.path || (item.path !== '/' && location.pathname.startsWith(`${item.path}/`));

                    return (
                      <NavLink
                        key={item.path}
                        to={item.path}
                        onClick={() => onClose && onClose()}
                        className={`group flex items-center justify-between px-3 py-2 text-xs font-medium rounded-lg transition-all duration-150 ${
                          isActive
                            ? 'bg-blue-600 text-white font-semibold shadow-sm'
                            : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                        }`}
                      >
                        <div className="flex items-center gap-3">
                          <Icon
                            className={`w-4 h-4 transition-colors ${
                              isActive ? 'text-white' : 'text-slate-400 group-hover:text-blue-400'
                            }`}
                          />
                          <span>{item.name}</span>
                        </div>

                        {item.status === 'upcoming' ? (
                          <span className="text-[10px] font-medium px-2 py-0.5 rounded-full bg-slate-800 text-slate-400 border border-slate-700/80">
                            Coming Soon
                          </span>
                        ) : (
                          <ChevronRight
                            className={`w-3.5 h-3.5 transition-transform ${
                              isActive ? 'text-white opacity-100' : 'text-slate-600 opacity-0 group-hover:opacity-100'
                            }`}
                          />
                        )}
                      </NavLink>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>

        {/* User Card & Logout Footer */}
        <div className="p-4 border-t border-slate-800 bg-slate-950/30">
          <div className="flex items-center justify-between">
            <Link
              to="/profile"
              onClick={() => onClose && onClose()}
              className="flex items-center gap-3 group flex-1 min-w-0 pr-2"
            >
              <div className="w-9 h-9 rounded-lg bg-slate-800 border border-slate-700 flex items-center justify-center text-blue-400 font-bold text-xs group-hover:border-blue-500 transition-colors">
                {user ? user.username.substring(0, 2).toUpperCase() : 'U'}
              </div>
              <div className="min-w-0 flex-1">
                <p className="text-xs font-semibold text-white truncate group-hover:text-blue-400 transition-colors">
                  {user ? user.full_name : 'User'}
                </p>
                <div className="flex items-center gap-1.5 mt-0.5">
                  <span className="text-[10px] px-1.5 py-0.2 rounded font-mono font-semibold bg-blue-500/10 text-blue-400 border border-blue-500/20">
                    {user ? user.role : 'GUEST'}
                  </span>
                </div>
              </div>
            </Link>

            <button
              type="button"
              onClick={logout}
              title="Sign Out"
              className="p-2 text-slate-400 hover:text-rose-400 hover:bg-slate-800/80 rounded-lg transition-colors focus:outline-none"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>
      </aside>
    </>
  );
};
