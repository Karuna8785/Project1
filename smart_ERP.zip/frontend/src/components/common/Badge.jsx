import React from 'react';

const badgeVariants = {
  blue: 'bg-blue-50 text-blue-700 border-blue-200/60',
  green: 'bg-emerald-50 text-emerald-700 border-emerald-200/60',
  red: 'bg-rose-50 text-rose-700 border-rose-200/60',
  amber: 'bg-amber-50 text-amber-700 border-amber-200/60',
  purple: 'bg-purple-50 text-purple-700 border-purple-200/60',
  indigo: 'bg-indigo-50 text-indigo-700 border-indigo-200/60',
  gray: 'bg-slate-100 text-slate-700 border-slate-200',
  dark: 'bg-slate-900 text-slate-100 border-slate-800',
};

const dotColors = {
  blue: 'bg-blue-500',
  green: 'bg-emerald-500',
  red: 'bg-rose-500',
  amber: 'bg-amber-500',
  purple: 'bg-purple-500',
  indigo: 'bg-indigo-500',
  gray: 'bg-slate-400',
  dark: 'bg-slate-300',
};

export const Badge = ({
  children,
  variant = 'blue',
  withDot = false,
  size = 'md',
  className = '',
}) => {
  const sizeClasses = size === 'sm' ? 'px-2 py-0.5 text-xs' : 'px-2.5 py-1 text-xs';
  const colorClass = badgeVariants[variant] || badgeVariants.gray;
  const dotColorClass = dotColors[variant] || dotColors.gray;

  return (
    <span
      className={`inline-flex items-center font-medium rounded-full border ${sizeClasses} ${colorClass} ${className}`}
    >
      {withDot && (
        <span className={`w-1.5 h-1.5 rounded-full mr-1.5 ${dotColorClass}`} />
      )}
      {children}
    </span>
  );
};
