import React from 'react';
import { CheckCircle2, AlertTriangle, AlertCircle, Info, X } from 'lucide-react';
import { useNotification } from '../../hooks/useNotification';

const toastStyles = {
  success: {
    bg: 'bg-emerald-900/90 text-white border-emerald-700/50',
    icon: CheckCircle2,
    iconColor: 'text-emerald-400',
  },
  error: {
    bg: 'bg-rose-900/90 text-white border-rose-700/50',
    icon: AlertCircle,
    iconColor: 'text-rose-400',
  },
  warning: {
    bg: 'bg-amber-900/90 text-white border-amber-700/50',
    icon: AlertTriangle,
    iconColor: 'text-amber-400',
  },
  info: {
    bg: 'bg-slate-900/90 text-white border-slate-700/50',
    icon: Info,
    iconColor: 'text-blue-400',
  },
};

export const ToastContainer = () => {
  const { toasts, removeToast } = useNotification();

  if (!toasts || toasts.length === 0) return null;

  return (
    <div className="fixed bottom-5 right-5 z-50 flex flex-col space-y-2.5 max-w-md w-full pointer-events-none">
      {toasts.map((toast) => {
        const style = toastStyles[toast.type] || toastStyles.info;
        const Icon = style.icon;

        return (
          <div
            key={toast.id}
            className={`pointer-events-auto flex items-start p-4 rounded-xl border backdrop-blur-md shadow-2xl transition-all duration-300 animate-fade-in ${style.bg}`}
          >
            <Icon className={`w-5 h-5 mr-3 flex-shrink-0 mt-0.5 ${style.iconColor}`} />
            <div className="flex-1 text-sm font-medium leading-5 pr-2">
              {toast.message}
            </div>
            <button
              onClick={() => removeToast(toast.id)}
              className="text-white/60 hover:text-white rounded-md p-1 transition-colors focus:outline-none"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        );
      })}
    </div>
  );
};
