import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import {
  ShieldCheck,
  Building2,
  Target,
  History,
  Users,
  CheckCircle2,
  ArrowRight,
  TrendingUp,
  Activity,
  Lock,
  LogOut,
  Sparkles,
} from 'lucide-react';
import { useAuth } from '../../hooks/useAuth';
import { crmService } from '../../services/crmService';
import { PageHeader } from '../../components/common/PageHeader';
import { StatCard } from '../../components/common/StatCard';
import { Card } from '../../components/common/Card';
import { Button } from '../../components/common/Button';
import { Badge } from '../../components/common/Badge';
import { formatCurrency, formatDate } from '../../utils/formatters';

export const Dashboard = () => {
  const { user, logout } = useAuth();
  const [stats, setStats] = useState({
    customers: { total_customers: 0, active_customers: 0, total_estimated_revenue: 0 },
    leads: { total_leads: 0, new_leads: 0, qualified_leads: 0, won_leads: 0, pipeline_value: 0, conversion_rate: 0 },
    recent_activities_count: 0,
    upcoming_followups_count: 0,
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadOverview = async () => {
      try {
        const data = await crmService.getOverview();
        setStats(data);
      } catch (err) {
        console.error('Error loading CRM stats:', err);
      } finally {
        setLoading(false);
      }
    };
    loadOverview();
  }, []);

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Top Banner / Announcement */}
      <div className="bg-gradient-to-r from-blue-900 via-indigo-900 to-slate-900 rounded-2xl p-6 sm:p-8 text-white shadow-xl relative overflow-hidden">
        <div className="absolute right-0 bottom-0 translate-x-10 translate-y-10 w-64 h-64 bg-blue-500/10 rounded-full blur-2xl pointer-events-none" />
        
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/20 border border-emerald-500/30 text-emerald-300 text-xs font-semibold">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
              Authentication module successfully connected.
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
              SmartERP Enterprise Dashboard
            </h1>
            <p className="text-sm text-slate-300 max-w-2xl leading-relaxed">
              Welcome back, <strong className="text-white">{user?.full_name}</strong>. Your session is active with role{' '}
              <span className="font-mono px-2 py-0.5 rounded bg-blue-500/30 text-blue-200 border border-blue-400/40 text-xs font-bold">
                {user?.role}
              </span>
              . Module 1 (Security &amp; RBAC) and Member 3 (CRM Management) are fully operational.
            </p>
          </div>

          <div className="flex items-center gap-3 flex-shrink-0">
            <Link to="/profile">
              <Button variant="outline" className="bg-white/10 hover:bg-white/20 text-white border-white/20">
                My Profile
              </Button>
            </Link>
            <Button
              variant="danger"
              onClick={logout}
              className="bg-rose-600/90 hover:bg-rose-600 text-white shadow-lg shadow-rose-600/20"
              icon={LogOut}
            >
              Sign Out
            </Button>
          </div>
        </div>
      </div>

      {/* User Connection & Role Summary Card */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        <Card className="border-l-4 border-l-blue-600">
          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center font-bold text-lg">
              {user?.username ? user.username.substring(0, 2).toUpperCase() : 'U'}
            </div>
            <div className="min-w-0 flex-1">
              <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Logged In User</p>
              <h3 className="text-base font-bold text-slate-900 truncate">{user?.full_name}</h3>
              <p className="text-xs text-slate-500 truncate">{user?.email}</p>
            </div>
          </div>
        </Card>

        <Card className="border-l-4 border-l-indigo-600">
          <div className="flex items-center gap-3.5">
            <div className="p-3 rounded-xl bg-indigo-50 text-indigo-600">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Assigned Security Role</p>
              <div className="flex items-center gap-2 mt-0.5">
                <span className="text-lg font-bold text-slate-900">{user?.role}</span>
                <Badge variant={user?.role === 'ADMIN' ? 'dark' : user?.role === 'MANAGER' ? 'indigo' : 'blue'}>
                  {user?.roles?.length || 1} Role(s)
                </Badge>
              </div>
              <p className="text-xs text-slate-500">{user?.permissions?.length || 0} active permissions</p>
            </div>
          </div>
        </Card>

        <Card className="border-l-4 border-l-emerald-600">
          <div className="flex items-center gap-3.5">
            <div className="p-3 rounded-xl bg-emerald-50 text-emerald-600">
              <CheckCircle2 className="w-6 h-6" />
            </div>
            <div>
              <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">System Architecture</p>
              <h3 className="text-base font-bold text-slate-900">PostgreSQL / FastAPI</h3>
              <p className="text-xs text-emerald-600 font-medium">Authentication &amp; CRM Live</p>
            </div>
          </div>
        </Card>
      </div>

      {/* Member 3 CRM Quick Metrics */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <h2 className="text-lg font-bold text-slate-900">Member 3 — CRM Pipeline &amp; Customer Metrics</h2>
            <Badge variant="green" withDot>Live Data</Badge>
          </div>
          <Link to="/crm" className="text-xs font-semibold text-blue-600 hover:text-blue-700 flex items-center gap-1">
            <span>View Full CRM Hub</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          <StatCard
            title="Total Customers"
            value={loading ? '...' : stats.customers.total_customers}
            subtitle={`${stats.customers.active_customers} Active Accounts`}
            icon={Building2}
            iconBg="bg-blue-50 text-blue-600"
          />
          <StatCard
            title="Pipeline Leads"
            value={loading ? '...' : stats.leads.total_leads}
            subtitle={`${stats.leads.qualified_leads} Qualified & In Progress`}
            icon={Target}
            iconBg="bg-purple-50 text-purple-600"
          />
          <StatCard
            title="Estimated Pipeline Value"
            value={loading ? '...' : formatCurrency(stats.leads.pipeline_value)}
            subtitle={`${stats.leads.conversion_rate}% Conversion Rate`}
            icon={TrendingUp}
            iconBg="bg-emerald-50 text-emerald-600"
          />
          <StatCard
            title="Interactions Logged"
            value={loading ? '...' : stats.recent_activities_count}
            subtitle={`${stats.upcoming_followups_count} Follow-ups Pending`}
            icon={History}
            iconBg="bg-amber-50 text-amber-600"
          />
        </div>
      </div>

      {/* Quick Actions & Navigation Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Module Status Roadmap */}
        <Card title="Enterprise ERP Modules Status" subtitle="Team module allocation breakdown">
          <div className="space-y-3">
            <div className="flex items-center justify-between p-3 rounded-lg bg-emerald-50/60 border border-emerald-100">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-emerald-600 text-white flex items-center justify-center font-bold text-xs">
                  M1
                </div>
                <div>
                  <h4 className="text-xs font-bold text-slate-900">Member 1: Authentication &amp; Security</h4>
                  <p className="text-[11px] text-slate-500">Login, Register, JWT, Roles, Permissions, Audit Logs</p>
                </div>
              </div>
              <Badge variant="green">Active</Badge>
            </div>

            <div className="flex items-center justify-between p-3 rounded-lg bg-emerald-50/60 border border-emerald-100">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-emerald-600 text-white flex items-center justify-center font-bold text-xs">
                  M3
                </div>
                <div>
                  <h4 className="text-xs font-bold text-slate-900">Member 3: CRM Management</h4>
                  <p className="text-[11px] text-slate-500">Customers, Leads, Customer Interaction History &amp; Pipeline</p>
                </div>
              </div>
              <Badge variant="green">Active</Badge>
            </div>

            <div className="flex items-center justify-between p-3 rounded-lg bg-slate-50 border border-slate-200/60">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-slate-200 text-slate-600 flex items-center justify-center font-bold text-xs">
                  M2
                </div>
                <div>
                  <h4 className="text-xs font-semibold text-slate-700">Member 2: HR Management</h4>
                  <p className="text-[11px] text-slate-400">Employees, Departments, Attendance, Leave</p>
                </div>
              </div>
              <Badge variant="gray">Coming Soon</Badge>
            </div>

            <div className="flex items-center justify-between p-3 rounded-lg bg-slate-50 border border-slate-200/60">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-slate-200 text-slate-600 flex items-center justify-center font-bold text-xs">
                  M4-6
                </div>
                <div>
                  <h4 className="text-xs font-semibold text-slate-700">Members 4, 5, 6: Inventory, Sales &amp; Finance</h4>
                  <p className="text-[11px] text-slate-400">Products, Orders, Invoices, Suppliers, Expenses</p>
                </div>
              </div>
              <Badge variant="gray">Coming Soon</Badge>
            </div>
          </div>
        </Card>

        {/* Quick Launchpad */}
        <Card title="Quick Action Launchpad" subtitle="Access primary features and records">
          <div className="grid grid-cols-2 gap-3">
            <Link
              to="/crm/customers"
              className="p-4 rounded-xl border border-slate-200/80 hover:border-blue-500 hover:shadow-sm bg-slate-50/50 hover:bg-blue-50/30 transition-all flex flex-col justify-between group"
            >
              <div className="p-2.5 rounded-lg bg-blue-100 text-blue-700 w-fit mb-3 group-hover:scale-105 transition-transform">
                <Building2 className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-slate-900 group-hover:text-blue-600 transition-colors">
                  Customer Directory
                </h4>
                <p className="text-xs text-slate-500 mt-0.5">Manage enterprise accounts</p>
              </div>
            </Link>

            <Link
              to="/crm/leads"
              className="p-4 rounded-xl border border-slate-200/80 hover:border-indigo-500 hover:shadow-sm bg-slate-50/50 hover:bg-indigo-50/30 transition-all flex flex-col justify-between group"
            >
              <div className="p-2.5 rounded-lg bg-indigo-100 text-indigo-700 w-fit mb-3 group-hover:scale-105 transition-transform">
                <Target className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-slate-900 group-hover:text-indigo-600 transition-colors">
                  Leads Pipeline
                </h4>
                <p className="text-xs text-slate-500 mt-0.5">Track opportunities &amp; conversions</p>
              </div>
            </Link>

            <Link
              to="/crm/history"
              className="p-4 rounded-xl border border-slate-200/80 hover:border-amber-500 hover:shadow-sm bg-slate-50/50 hover:bg-amber-50/30 transition-all flex flex-col justify-between group"
            >
              <div className="p-2.5 rounded-lg bg-amber-100 text-amber-700 w-fit mb-3 group-hover:scale-105 transition-transform">
                <History className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-slate-900 group-hover:text-amber-600 transition-colors">
                  Activity Logs
                </h4>
                <p className="text-xs text-slate-500 mt-0.5">Timeline &amp; follow-up tasks</p>
              </div>
            </Link>

            <Link
              to="/profile"
              className="p-4 rounded-xl border border-slate-200/80 hover:border-purple-500 hover:shadow-sm bg-slate-50/50 hover:bg-purple-50/30 transition-all flex flex-col justify-between group"
            >
              <div className="p-2.5 rounded-lg bg-purple-100 text-purple-700 w-fit mb-3 group-hover:scale-105 transition-transform">
                <Lock className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-slate-900 group-hover:text-purple-600 transition-colors">
                  Profile &amp; Security
                </h4>
                <p className="text-xs text-slate-500 mt-0.5">RBAC &amp; password settings</p>
              </div>
            </Link>
          </div>
        </Card>
      </div>
    </div>
  );
};
