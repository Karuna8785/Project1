import React, { useState, useEffect } from 'react';
import {
  User as UserIcon,
  Mail,
  ShieldCheck,
  Lock,
  KeyRound,
  CheckCircle2,
  AlertCircle,
  Clock,
  ShieldAlert,
} from 'lucide-react';
import { useAuth } from '../../hooks/useAuth';
import { useNotification } from '../../hooks/useNotification';
import { authService } from '../../services/authService';
import { auditService } from '../../services/auditService';
import { PageHeader } from '../../components/common/PageHeader';
import { Card } from '../../components/common/Card';
import { Input } from '../../components/common/Input';
import { Button } from '../../components/common/Button';
import { Badge } from '../../components/common/Badge';
import { formatDate } from '../../utils/formatters';

export const Profile = () => {
  const { user, refreshProfile } = useAuth();
  const { notifySuccess, notifyError } = useNotification();

  const [passwordData, setPasswordData] = useState({
    old_password: '',
    new_password: '',
    confirm_password: '',
  });
  const [pwdLoading, setPwdLoading] = useState(false);
  const [pwdError, setPwdError] = useState('');

  const [myLogs, setMyLogs] = useState([]);
  const [logsLoading, setLogsLoading] = useState(true);

  useEffect(() => {
    const fetchLogs = async () => {
      try {
        const data = await auditService.getMyLogs(10);
        setMyLogs(data);
      } catch (e) {
        console.error('Error fetching personal logs:', e);
      } finally {
        setLogsLoading(false);
      }
    };
    fetchLogs();
  }, []);

  const handlePasswordSubmit = async (e) => {
    e.preventDefault();
    if (!passwordData.old_password || !passwordData.new_password) {
      setPwdError('Please complete all password fields.');
      return;
    }
    if (passwordData.new_password !== passwordData.confirm_password) {
      setPwdError('New passwords do not match.');
      return;
    }
    if (passwordData.new_password.length < 6) {
      setPwdError('New password must be at least 6 characters.');
      return;
    }

    setPwdError('');
    setPwdLoading(true);

    try {
      const res = await authService.changePassword(
        passwordData.old_password,
        passwordData.new_password,
        passwordData.confirm_password
      );
      if (res.error) {
        setPwdError(res.error);
        notifyError(res.error);
      } else {
        notifySuccess('Password changed successfully.');
        setPasswordData({ old_password: '', new_password: '', confirm_password: '' });
      }
    } catch (err) {
      const msg = err.extractedMessage || 'Failed to change password.';
      setPwdError(msg);
      notifyError(msg);
    } finally {
      setPwdLoading(false);
    }
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <PageHeader
        title="User Profile & Security"
        subtitle="Manage your authentication credentials, view assigned roles and permissions"
      />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* User Card */}
        <div className="lg:col-span-1 space-y-6">
          <Card>
            <div className="text-center pb-6 border-b border-slate-100">
              <div className="w-20 h-20 rounded-2xl bg-gradient-to-tr from-blue-600 to-indigo-600 flex items-center justify-center text-white text-2xl font-bold mx-auto mb-4 shadow-lg shadow-blue-500/20">
                {user?.username ? user.username.substring(0, 2).toUpperCase() : 'U'}
              </div>
              <h2 className="text-lg font-bold text-slate-900">{user?.full_name}</h2>
              <p className="text-xs text-slate-500 font-mono">@{user?.username}</p>
              
              <div className="mt-3 flex justify-center gap-1.5 flex-wrap">
                {user?.roles?.map((r) => (
                  <Badge key={r} variant={r === 'ADMIN' ? 'dark' : r === 'MANAGER' ? 'indigo' : 'blue'}>
                    {r}
                  </Badge>
                ))}
              </div>
            </div>

            <div className="pt-5 space-y-3.5 text-xs">
              <div className="flex items-center justify-between text-slate-600">
                <span className="flex items-center gap-2 text-slate-400">
                  <Mail className="w-4 h-4" /> Email
                </span>
                <span className="font-medium text-slate-900 truncate max-w-[180px]">{user?.email}</span>
              </div>

              <div className="flex items-center justify-between text-slate-600">
                <span className="flex items-center gap-2 text-slate-400">
                  <ShieldCheck className="w-4 h-4" /> Account Status
                </span>
                <span className="font-semibold text-emerald-600 flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" /> Active
                </span>
              </div>

              <div className="flex items-center justify-between text-slate-600">
                <span className="flex items-center gap-2 text-slate-400">
                  <Clock className="w-4 h-4" /> Member Since
                </span>
                <span className="font-medium text-slate-900">
                  {user?.created_at ? formatDate(user.created_at) : 'Current Session'}
                </span>
              </div>
            </div>
          </Card>

          {/* Assigned Permissions */}
          <Card title="Effective Permissions" subtitle="Granted via assigned roles">
            <div className="max-h-56 overflow-y-auto pr-1 space-y-1.5">
              {user?.permissions && user.permissions.length > 0 ? (
                user.permissions.map((perm) => (
                  <div
                    key={perm}
                    className="flex items-center gap-2 p-2 rounded-lg bg-slate-50 border border-slate-100 text-[11px] font-mono text-slate-700"
                  >
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500 flex-shrink-0" />
                    <span className="truncate">{perm}</span>
                  </div>
                ))
              ) : (
                <p className="text-xs text-slate-400 italic">No special permissions mapped.</p>
              )}
            </div>
          </Card>
        </div>

        {/* Right Section: Change Password & Security Log */}
        <div className="lg:col-span-2 space-y-6">
          {/* Change Password Form */}
          <Card
            title="Update Password"
            subtitle="Ensure your account uses a strong password with at least 6 characters"
          >
            {pwdError && (
              <div className="mb-4 p-3 rounded-lg bg-rose-50 border border-rose-200 flex items-start gap-2.5 text-xs text-rose-700">
                <AlertCircle className="w-4 h-4 text-rose-500 flex-shrink-0 mt-0.5" />
                <span>{pwdError}</span>
              </div>
            )}

            <form onSubmit={handlePasswordSubmit} className="space-y-4 max-w-md">
              <Input
                label="Current Password"
                type="password"
                required
                value={passwordData.old_password}
                onChange={(e) => setPasswordData({ ...passwordData, old_password: e.target.value })}
                placeholder="Enter existing password"
                icon={Lock}
              />

              <Input
                label="New Password"
                type="password"
                required
                value={passwordData.new_password}
                onChange={(e) => setPasswordData({ ...passwordData, new_password: e.target.value })}
                placeholder="Enter new strong password"
                icon={KeyRound}
              />

              <Input
                label="Confirm New Password"
                type="password"
                required
                value={passwordData.confirm_password}
                onChange={(e) => setPasswordData({ ...passwordData, confirm_password: e.target.value })}
                placeholder="Re-enter new password"
                icon={KeyRound}
              />

              <div className="pt-2">
                <Button
                  type="submit"
                  variant="primary"
                  isLoading={pwdLoading}
                >
                  Update Password
                </Button>
              </div>
            </form>
          </Card>

          {/* Recent User Security Logs */}
          <Card
            title="Personal Security Audit Trail"
            subtitle="Your recent login, password updates, and session security events"
          >
            {logsLoading ? (
              <p className="text-xs text-slate-400">Loading security logs...</p>
            ) : myLogs.length === 0 ? (
              <p className="text-xs text-slate-400">No recent security events recorded.</p>
            ) : (
              <div className="divide-y divide-slate-100 text-xs">
                {myLogs.map((log) => (
                  <div key={log.id} className="py-3 flex items-center justify-between">
                    <div className="space-y-0.5">
                      <p className="font-semibold text-slate-900 font-mono text-[11px]">{log.action}</p>
                      <p className="text-[11px] text-slate-500">
                        IP: {log.ip_address || '127.0.0.1'} &bull; {log.details || 'User session verified'}
                      </p>
                    </div>
                    <span className="text-[11px] text-slate-400">{formatDate(log.created_at, true)}</span>
                  </div>
                ))}
              </div>
            )}
          </Card>
        </div>
      </div>
    </div>
  );
};
