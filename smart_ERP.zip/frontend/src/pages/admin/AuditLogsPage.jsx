import React, { useState, useEffect } from 'react';
import {
  ShieldAlert,
  Search,
  Filter,
  RefreshCw,
  Clock,
  Shield,
  User,
  Info,
} from 'lucide-react';
import { auditService } from '../../services/auditService';
import { PageHeader } from '../../components/common/PageHeader';
import { Card } from '../../components/common/Card';
import { Button } from '../../components/common/Button';
import { Table } from '../../components/common/Table';
import { Badge } from '../../components/common/Badge';
import { formatDate } from '../../utils/formatters';

export const AuditLogsPage = () => {
  const [logs, setLogs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [actionFilter, setActionFilter] = useState('');

  const fetchLogs = async () => {
    setLoading(true);
    try {
      const params = {};
      if (actionFilter) params.action = actionFilter;
      const data = await auditService.getLogs(params);
      setLogs(data);
    } catch (err) {
      console.error('Error fetching audit logs:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchLogs();
  }, [actionFilter]);

  const columns = [
    {
      header: 'Timestamp',
      accessor: 'created_at',
      cellClassName: 'text-xs text-slate-500 whitespace-nowrap',
      render: (row) => <span>{formatDate(row.created_at, true)}</span>,
    },
    {
      header: 'Security Action',
      accessor: 'action',
      render: (row) => {
        const isFailed = row.action.includes('FAILED') || row.action.includes('REJECTED');
        const isSuccess = row.action.includes('SUCCESS');
        return (
          <Badge
            variant={isFailed ? 'red' : isSuccess ? 'green' : 'blue'}
            size="sm"
            className="font-mono"
          >
            {row.action}
          </Badge>
        );
      },
    },
    {
      header: 'Actor / User',
      accessor: 'user_email',
      render: (row) => (
        <span className="text-xs font-semibold text-slate-900">
          {row.user_email || `User #${row.user_id}` || 'Anonymous'}
        </span>
      ),
    },
    {
      header: 'IP Address',
      accessor: 'ip_address',
      cellClassName: 'font-mono text-xs text-slate-500',
      render: (row) => <span>{row.ip_address || '127.0.0.1'}</span>,
    },
    {
      header: 'Details',
      accessor: 'details',
      render: (row) => (
        <span className="text-xs text-slate-600 truncate max-w-md block">
          {row.details || '—'}
        </span>
      ),
    },
  ];

  return (
    <div className="space-y-6 animate-fade-in">
      <PageHeader
        title="Security Audit Logs"
        subtitle="Immutable security event tracking, login audits, user creations, and RBAC operations"
        badge={<Badge variant="dark">{logs.length} Events</Badge>}
      >
        <Button
          variant="outline"
          icon={RefreshCw}
          onClick={fetchLogs}
          isLoading={loading}
        >
          Refresh Logs
        </Button>
      </PageHeader>

      <Card noPadding className="p-4 bg-white">
        <div className="flex items-center gap-3">
          <select
            value={actionFilter}
            onChange={(e) => setActionFilter(e.target.value)}
            className="text-xs border border-slate-200 rounded-lg px-3 py-2 bg-white text-slate-700 focus:outline-none focus:border-blue-500"
          >
            <option value="">All Security Actions</option>
            <option value="LOGIN_SUCCESS">LOGIN_SUCCESS</option>
            <option value="LOGIN_FAILED_WRONG_PASSWORD">LOGIN_FAILED_WRONG_PASSWORD</option>
            <option value="LOGIN_FAILED_USER_NOT_FOUND">LOGIN_FAILED_USER_NOT_FOUND</option>
            <option value="LOGOUT">LOGOUT</option>
            <option value="REGISTRATION_SUCCESS">REGISTRATION_SUCCESS</option>
            <option value="CRM_CUSTOMER_CREATED">CRM_CUSTOMER_CREATED</option>
            <option value="CRM_LEAD_CREATED">CRM_LEAD_CREATED</option>
            <option value="CRM_LEAD_CONVERTED_TO_CUSTOMER">CRM_LEAD_CONVERTED_TO_CUSTOMER</option>
          </select>
        </div>
      </Card>

      <Card noPadding>
        <Table
          columns={columns}
          data={logs}
          isLoading={loading}
          emptyMessage="No audit logs match current filter."
        />
      </Card>
    </div>
  );
};
