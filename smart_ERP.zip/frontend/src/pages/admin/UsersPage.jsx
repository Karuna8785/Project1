import React, { useState, useEffect } from 'react';
import {
  UserCheck,
  Plus,
  Shield,
  KeyRound,
  CheckCircle2,
  XCircle,
  AlertCircle,
  Mail,
  User,
} from 'lucide-react';
import { userService } from '../../services/userService';
import { useAuth } from '../../hooks/useAuth';
import { useNotification } from '../../hooks/useNotification';
import { PageHeader } from '../../components/common/PageHeader';
import { Card } from '../../components/common/Card';
import { Button } from '../../components/common/Button';
import { Table } from '../../components/common/Table';
import { Badge } from '../../components/common/Badge';
import { Modal } from '../../components/common/Modal';
import { Input } from '../../components/common/Input';
import { formatDate } from '../../utils/formatters';

export const UsersPage = () => {
  const { hasRole } = useAuth();
  const { notifySuccess, notifyError } = useNotification();

  const [users, setUsers] = useState([]);
  const [roles, setRoles] = useState([]);
  const [loading, setLoading] = useState(true);

  // Create User Modal
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [createData, setCreateData] = useState({
    full_name: '',
    email: '',
    username: '',
    password: '',
    role_names: ['EMPLOYEE'],
  });

  // Assign Role Modal
  const [selectedUser, setSelectedUser] = useState(null);
  const [assignedRoleIds, setAssignedRoleIds] = useState([]);

  const fetchData = async () => {
    setLoading(true);
    try {
      const [uList, rList] = await Promise.all([
        userService.getUsers(),
        userService.getRoles(),
      ]);
      setUsers(uList);
      setRoles(rList);
    } catch (err) {
      console.error('Error fetching users:', err);
      notifyError('Failed to fetch user accounts.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleCreateUser = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      await userService.createUser(createData);
      notifySuccess(`User ${createData.username} created successfully!`);
      setIsCreateModalOpen(false);
      setCreateData({
        full_name: '',
        email: '',
        username: '',
        password: '',
        role_names: ['EMPLOYEE'],
      });
      fetchData();
    } catch (err) {
      notifyError(err.extractedMessage || 'Error creating user.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleOpenRoleModal = (user) => {
    setSelectedUser(user);
    // Find role IDs
    const matchedRoleIds = roles
      .filter((r) => user.roles?.includes(r.name))
      .map((r) => r.id);
    setAssignedRoleIds(matchedRoleIds);
  };

  const handleSaveRoles = async () => {
    if (!selectedUser) return;
    try {
      await userService.assignRoles(selectedUser.id, assignedRoleIds);
      notifySuccess(`Roles updated for ${selectedUser.username}.`);
      setSelectedUser(null);
      fetchData();
    } catch (err) {
      notifyError(err.extractedMessage || 'Failed to update roles.');
    }
  };

  const columns = [
    {
      header: 'User Account',
      accessor: 'full_name',
      render: (row) => (
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-blue-50 text-blue-600 font-bold text-xs flex items-center justify-center">
            {row.username.substring(0, 2).toUpperCase()}
          </div>
          <div>
            <p className="font-bold text-slate-900">{row.full_name}</p>
            <p className="text-xs text-slate-500 font-mono">@{row.username}</p>
          </div>
        </div>
      ),
    },
    {
      header: 'Email',
      accessor: 'email',
      cellClassName: 'text-xs text-slate-600',
    },
    {
      header: 'Roles & Access',
      accessor: 'role',
      render: (row) => (
        <div className="flex items-center gap-1.5 flex-wrap">
          {row.roles?.map((r) => (
            <Badge key={r} variant={r === 'ADMIN' ? 'dark' : r === 'MANAGER' ? 'indigo' : 'blue'} size="sm">
              {r}
            </Badge>
          ))}
        </div>
      ),
    },
    {
      header: 'Permissions',
      accessor: 'permissions',
      render: (row) => (
        <span className="text-xs text-slate-500 font-medium">
          {row.permissions?.length || 0} active
        </span>
      ),
    },
    {
      header: 'Status',
      accessor: 'is_active',
      render: (row) => (
        <Badge variant={row.is_active ? 'green' : 'red'} withDot size="sm">
          {row.is_active ? 'Active' : 'Deactivated'}
        </Badge>
      ),
    },
    {
      header: 'Joined',
      accessor: 'created_at',
      render: (row) => (
        <span className="text-xs text-slate-400">{formatDate(row.created_at)}</span>
      ),
    },
    {
      header: 'Actions',
      accessor: 'actions',
      className: 'text-right',
      cellClassName: 'text-right',
      render: (row) => (
        hasRole(['ADMIN']) && (
          <Button
            size="sm"
            variant="outline"
            className="text-xs py-1 px-2.5"
            onClick={() => handleOpenRoleModal(row)}
          >
            Assign Roles
          </Button>
        )
      ),
    },
  ];

  return (
    <div className="space-y-6 animate-fade-in">
      <PageHeader
        title="User & Access Control"
        subtitle="Manage SmartERP system users, assign enterprise security roles, and inspect permissions"
        badge={<Badge variant="blue">{users.length} Users</Badge>}
      >
        {hasRole(['ADMIN']) && (
          <Button
            variant="primary"
            icon={Plus}
            onClick={() => setIsCreateModalOpen(true)}
          >
            Create User
          </Button>
        )}
      </PageHeader>

      <Card noPadding>
        <Table
          columns={columns}
          data={users}
          isLoading={loading}
          emptyMessage="No users found."
        />
      </Card>

      {/* Create User Modal */}
      <Modal
        isOpen={isCreateModalOpen}
        onClose={() => setIsCreateModalOpen(false)}
        title="Create System User"
        subtitle="Add a new employee or administrator to SmartERP"
      >
        <form onSubmit={handleCreateUser} className="space-y-4">
          <Input
            label="Full Name"
            required
            value={createData.full_name}
            onChange={(e) => setCreateData({ ...createData, full_name: e.target.value })}
            placeholder="e.g. John Doe"
          />

          <Input
            label="Work Email"
            type="email"
            required
            value={createData.email}
            onChange={(e) => setCreateData({ ...createData, email: e.target.value })}
            placeholder="john.doe@smarterp.com"
          />

          <Input
            label="Username"
            required
            value={createData.username}
            onChange={(e) => setCreateData({ ...createData, username: e.target.value })}
            placeholder="johndoe"
          />

          <Input
            label="Password"
            type="password"
            required
            value={createData.password}
            onChange={(e) => setCreateData({ ...createData, password: e.target.value })}
            placeholder="••••••••••••"
          />

          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-700 mb-1.5">
              Initial Role
            </label>
            <select
              value={createData.role_names[0]}
              onChange={(e) => setCreateData({ ...createData, role_names: [e.target.value] })}
              className="w-full text-sm border border-slate-300 rounded-lg p-2.5 bg-white focus:outline-none focus:ring-2 focus:ring-blue-100 focus:border-blue-500"
            >
              <option value="EMPLOYEE">Employee (Standard Access)</option>
              <option value="MANAGER">Manager (CRM &amp; Operations)</option>
              <option value="ADMIN">Admin (Unrestricted System Access)</option>
            </select>
          </div>

          <div className="pt-4 border-t border-slate-100 flex items-center justify-end gap-3">
            <Button
              variant="outline"
              onClick={() => setIsCreateModalOpen(false)}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              variant="primary"
              isLoading={submitting}
            >
              Create Account
            </Button>
          </div>
        </form>
      </Modal>

      {/* Role Assignment Modal */}
      <Modal
        isOpen={!!selectedUser}
        onClose={() => setSelectedUser(null)}
        title="Assign Roles"
        subtitle={`Select security roles for @${selectedUser?.username}`}
      >
        <div className="space-y-4">
          <div className="space-y-2">
            {roles.map((r) => {
              const isChecked = assignedRoleIds.includes(r.id);
              return (
                <label
                  key={r.id}
                  className={`flex items-start gap-3 p-3.5 rounded-xl border transition-all cursor-pointer ${
                    isChecked
                      ? 'bg-blue-50/60 border-blue-400'
                      : 'bg-white border-slate-200 hover:bg-slate-50'
                  }`}
                >
                  <input
                    type="checkbox"
                    checked={isChecked}
                    onChange={(e) => {
                      if (e.target.checked) {
                        setAssignedRoleIds([...assignedRoleIds, r.id]);
                      } else {
                        setAssignedRoleIds(assignedRoleIds.filter((id) => id !== r.id));
                      }
                    }}
                    className="mt-0.5 rounded text-blue-600 focus:ring-blue-500"
                  />
                  <div>
                    <span className="text-xs font-bold text-slate-900 block">{r.name}</span>
                    <span className="text-[11px] text-slate-500">{r.description}</span>
                  </div>
                </label>
              );
            })}
          </div>

          <div className="pt-4 border-t border-slate-100 flex items-center justify-end gap-3">
            <Button
              variant="outline"
              onClick={() => setSelectedUser(null)}
            >
              Cancel
            </Button>
            <Button
              variant="primary"
              onClick={handleSaveRoles}
            >
              Save Role Changes
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  );
};
