import React from 'react';
import { useLocation, Link } from 'react-router-dom';
import { Construction, ArrowLeft, ShieldCheck, Sparkles } from 'lucide-react';
import { PageHeader } from '../../components/common/PageHeader';
import { Card } from '../../components/common/Card';
import { Button } from '../../components/common/Button';
import { Badge } from '../../components/common/Badge';

const moduleDetails = {
  '/hr': {
    name: 'HR Management',
    member: 'Member 2',
    description: 'Employee directory, departments, attendance tracking, and leave request workflows.',
  },
  '/inventory': {
    name: 'Inventory & Warehousing',
    member: 'Member 4',
    description: 'Product catalog, categories, multi-warehouse stock levels, and stock movement auditing.',
  },
  '/sales': {
    name: 'Sales & Invoicing',
    member: 'Member 5',
    description: 'Sales quotations, sales orders, automated invoicing, and payment reconciliation.',
  },
  '/procurement': {
    name: 'Procurement & Purchasing',
    member: 'Member 6',
    description: 'Supplier vendor database, purchase orders, receiving docks, and vendor SLA management.',
  },
  '/finance': {
    name: 'Finance & Accounting',
    member: 'Member 6',
    description: 'General ledger, expense claims, financial accounts, and fiscal year tracking.',
  },
  '/reports': {
    name: 'Reports & Analytics',
    member: 'Member 7',
    description: 'Cross-module executive dashboards, BI data exports, PDF reporting, and KPI charts.',
  },
};

export const ModulePlaceholder = () => {
  const location = useLocation();
  const info = moduleDetails[location.pathname] || {
    name: 'Enterprise Module',
    member: 'Future Team Phase',
    description: 'This module is scheduled for implementation in Phase 2.',
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <PageHeader
        title={info.name}
        subtitle={`Architecture placeholder reserved for ${info.member}`}
        badge={<Badge variant="gray">Phase 2 Planned</Badge>}
      >
        <Link to="/dashboard">
          <Button variant="outline" icon={ArrowLeft}>
            Back to Dashboard
          </Button>
        </Link>
      </PageHeader>

      <Card className="text-center py-16 px-6 max-w-2xl mx-auto">
        <div className="w-16 h-16 rounded-2xl bg-slate-100 text-slate-500 flex items-center justify-center mx-auto mb-5 border border-slate-200">
          <Construction className="w-8 h-8" />
        </div>

        <h2 className="text-2xl font-bold text-slate-900 mb-2">Coming Soon</h2>
        <p className="text-sm font-semibold text-blue-600 mb-3">{info.member} Allocation</p>
        
        <p className="text-xs text-slate-500 max-w-md mx-auto leading-relaxed mb-8">
          {info.description}
        </p>

        <div className="p-4 rounded-xl bg-slate-50 border border-slate-100 text-left text-xs text-slate-600 space-y-2 mb-6">
          <div className="flex items-center gap-2 font-bold text-slate-900">
            <ShieldCheck className="w-4 h-4 text-emerald-500" />
            <span>Architecture Readiness:</span>
          </div>
          <p>&bull; Backend database schema and route blueprints are registered in FastAPI.</p>
          <p>&bull; Frontend routing and role-based navigation are fully connected.</p>
          <p>&bull; Modular structure ensures zero breaking changes upon Phase 2 rollout.</p>
        </div>

        <Link to="/crm">
          <Button variant="primary">
            Explore Active CRM Module (Member 3) &rarr;
          </Button>
        </Link>
      </Card>
    </div>
  );
};
