import React, { useState, useEffect } from 'react';
import {
  Target,
  Plus,
  Search,
  Filter,
  ArrowRight,
  Trash2,
  Edit,
  Mail,
  Phone,
  Building2,
  CheckCircle2,
  UserCheck,
  Sparkles,
  AlertCircle,
  TrendingUp,
} from 'lucide-react';
import { crmService } from '../../services/crmService';
import { useAuth } from '../../hooks/useAuth';
import { useNotification } from '../../hooks/useNotification';
import { PageHeader } from '../../components/common/PageHeader';
import { Card } from '../../components/common/Card';
import { Button } from '../../components/common/Button';
import { Input } from '../../components/common/Input';
import { Table } from '../../components/common/Table';
import { Badge } from '../../components/common/Badge';
import { Modal } from '../../components/common/Modal';
import { LEAD_STATUS, LEAD_SOURCES } from '../../utils/constants';
import { formatCurrency, formatDate } from '../../utils/formatters';

export const LeadsPage = () => {
  const { hasRole } = useAuth();
  const { notifySuccess, notifyError } = useNotification();

  const [leads, setLeads] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [sourceFilter, setSourceFilter] = useState('');

  // Add Lead Modal
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [formError, setFormError] = useState('');
  const [formData, setFormData] = useState({
    first_name: '',
    last_name: '',
    email: '',
    phone: '',
    company: '',
    title: '',
    lead_source: 'WEBSITE',
    lead_status: 'NEW',
    lead_score: 60,
    estimated_value: '',
    notes: '',
  });

  // Convert Lead Modal
  const [convertModalLead, setConvertModalLead] = useState(null);
  const [convertData, setConvertData] = useState({
    customer_type: 'CORPORATE',
    industry: 'Technology',
    create_interaction_note: 'Converted from sales pipeline lead.',
  });
  const [converting, setConverting] = useState(false);

  const fetchLeads = async () => {
    setLoading(true);
    try {
      const params = {};
      if (search) params.search = search;
      if (statusFilter) params.status = statusFilter;
      if (sourceFilter) params.lead_source = sourceFilter;
      const data = await crmService.getLeads(params);
      setLeads(data);
    } catch (err) {
      console.error('Error fetching leads:', err);
      notifyError('Failed to fetch pipeline leads.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    const delay = setTimeout(() => {
      fetchLeads();
    }, 250);
    return () => clearTimeout(delay);
  }, [search, statusFilter, sourceFilter]);

  const handleInputChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
    setFormError('');
  };

  const handleCreateLead = async (e) => {
    e.preventDefault();
    if (!formData.first_name.trim() || !formData.last_name.trim() || !formData.email.trim()) {
      setFormError('First Name, Last Name, and Email are required.');
      return;
    }

    setSubmitting(true);
    try {
      const payload = {
        ...formData,
        lead_score: parseInt(formData.lead_score) || 50,
        estimated_value: formData.estimated_value ? parseFloat(formData.estimated_value) : 0,
      };
      await crmService.createLead(payload);
      notifySuccess(`Lead "${formData.first_name} ${formData.last_name}" added to pipeline!`);
      setIsAddModalOpen(false);
      setFormData({
        first_name: '',
        last_name: '',
        email: '',
        phone: '',
        company: '',
        title: '',
        lead_source: 'WEBSITE',
        lead_status: 'NEW',
        lead_score: 60,
        estimated_value: '',
        notes: '',
      });
      fetchLeads();
    } catch (err) {
      const msg = err.extractedMessage || 'Error creating lead.';
      setFormError(msg);
      notifyError(msg);
    } finally {
      setSubmitting(false);
    }
  };

  const handleConvertLead = async (e) => {
    e.preventDefault();
    if (!convertModalLead) return;

    setConverting(true);
    try {
      await crmService.convertLead(convertModalLead.id, convertData);
      notifySuccess(`Lead "${convertModalLead.full_name}" converted into a Customer!`);
      setConvertModalLead(null);
      fetchLeads();
    } catch (err) {
      notifyError(err.extractedMessage || 'Failed to convert lead.');
    } finally {
      setConverting(false);
    }
  };

  const handleStatusChange = async (leadId, newStatus) => {
    try {
      await crmService.updateLead(leadId, { lead_status: newStatus });
      notifySuccess(`Lead status updated to ${newStatus}`);
      fetchLeads();
    } catch (err) {
      notifyError(err.extractedMessage || 'Failed to update lead status.');
    }
  };

  const handleDeleteLead = async (leadId, name) => {
    if (!window.confirm(`Delete lead "${name}"?`)) return;
    try {
      await crmService.deleteLead(leadId);
      notifySuccess(`Lead deleted.`);
      fetchLeads();
    } catch (err) {
      notifyError(err.extractedMessage || 'Error deleting lead.');
    }
  };

  const columns = [
    {
      header: 'Lead Name & Role',
      accessor: 'full_name',
      render: (row) => (
        <div>
          <p className="font-bold text-slate-900">{row.full_name}</p>
          <p className="text-xs text-slate-500">
            {row.title ? `${row.title} at ` : ''}
            <span className="font-medium text-slate-700">{row.company || 'Individual'}</span>
          </p>
        </div>
      ),
    },
    {
      header: 'Contact',
      accessor: 'email',
      render: (row) => (
        <div className="space-y-0.5 text-xs">
          <p className="text-slate-700 flex items-center gap-1.5">
            <Mail className="w-3.5 h-3.5 text-slate-400" />
            {row.email}
          </p>
          {row.phone && (
            <p className="text-slate-500 flex items-center gap-1.5">
              <Phone className="w-3.5 h-3.5 text-slate-400" />
              {row.phone}
            </p>
          )}
        </div>
      ),
    },
    {
      header: 'Pipeline Stage',
      accessor: 'lead_status',
      render: (row) => {
        const conf = LEAD_STATUS[row.lead_status] || { label: row.lead_status, color: 'blue' };
        return (
          <div className="flex items-center gap-2">
            <select
              value={row.lead_status}
              disabled={row.lead_status === 'WON'}
              onChange={(e) => handleStatusChange(row.id, e.target.value)}
              className="text-xs font-semibold rounded-lg border border-slate-200 px-2 py-1 bg-white text-slate-700 focus:outline-none focus:border-blue-500 disabled:opacity-75 disabled:bg-slate-50"
            >
              {Object.keys(LEAD_STATUS).map((st) => (
                <option key={st} value={st}>
                  {LEAD_STATUS[st].label}
                </option>
              ))}
            </select>
          </div>
        );
      },
    },
    {
      header: 'Score',
      accessor: 'lead_score',
      render: (row) => {
        const score = row.lead_score || 50;
        const color =
          score >= 80
            ? 'bg-emerald-500 text-white'
            : score >= 60
            ? 'bg-indigo-500 text-white'
            : 'bg-amber-500 text-white';
        return (
          <div className="flex items-center gap-1.5">
            <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded-md ${color}`}>
              {score}/100
            </span>
            <span className="text-[10px] text-slate-400 uppercase font-medium">{row.lead_source}</span>
          </div>
        );
      },
    },
    {
      header: 'Est. Value',
      accessor: 'estimated_value',
      render: (row) => (
        <span className="font-semibold text-slate-900 text-xs">
          {formatCurrency(row.estimated_value)}
        </span>
      ),
    },
    {
      header: 'Actions',
      accessor: 'actions',
      className: 'text-right',
      cellClassName: 'text-right',
      render: (row) => (
        <div className="flex items-center justify-end gap-2">
          {row.lead_status !== 'WON' && !row.converted_customer_id ? (
            <Button
              size="sm"
              variant="outline"
              className="text-xs py-1 px-2 text-emerald-700 border-emerald-200 bg-emerald-50 hover:bg-emerald-100"
              icon={UserCheck}
              onClick={() => setConvertModalLead(row)}
            >
              Convert
            </Button>
          ) : (
            <Badge variant="green" size="sm">
              Converted
            </Badge>
          )}

          {hasRole(['ADMIN', 'MANAGER']) && (
            <Button
              size="sm"
              variant="ghost"
              className="p-1.5 hover:text-rose-600"
              onClick={() => handleDeleteLead(row.id, row.full_name)}
              title="Delete Lead"
            >
              <Trash2 className="w-4 h-4" />
            </Button>
          )}
        </div>
      ),
    },
  ];

  return (
    <div className="space-y-6 animate-fade-in">
      <PageHeader
        title="Sales Leads Pipeline"
        subtitle="Track potential business opportunities, lead qualification, and customer conversions"
        badge={<Badge variant="purple">{leads.length} Leads</Badge>}
      >
        <Button
          variant="primary"
          icon={Plus}
          onClick={() => setIsAddModalOpen(true)}
        >
          Add Lead
        </Button>
      </PageHeader>

      {/* Filter Bar */}
      <Card noPadding className="p-4 bg-white">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="relative flex-1 w-full">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Search leads by name, company, email..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-9 pr-4 py-2 text-xs rounded-lg border border-slate-200 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
            />
          </div>

          <div className="flex items-center gap-2.5 w-full sm:w-auto">
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="text-xs border border-slate-200 rounded-lg px-3 py-2 bg-white text-slate-700 focus:outline-none focus:border-blue-500"
            >
              <option value="">All Pipeline Stages</option>
              {Object.keys(LEAD_STATUS).map((st) => (
                <option key={st} value={st}>
                  {LEAD_STATUS[st].label}
                </option>
              ))}
            </select>

            <select
              value={sourceFilter}
              onChange={(e) => setSourceFilter(e.target.value)}
              className="text-xs border border-slate-200 rounded-lg px-3 py-2 bg-white text-slate-700 focus:outline-none focus:border-blue-500"
            >
              <option value="">All Sources</option>
              {LEAD_SOURCES.map((src) => (
                <option key={src} value={src}>
                  {src}
                </option>
              ))}
            </select>
          </div>
        </div>
      </Card>

      {/* Leads Table */}
      <Card noPadding>
        <Table
          columns={columns}
          data={leads}
          isLoading={loading}
          emptyMessage="No sales leads in the current filter. Click 'Add Lead' to add new prospects."
        />
      </Card>

      {/* Add Lead Modal */}
      <Modal
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
        title="Add New Sales Lead"
        subtitle="Capture opportunity information into the CRM pipeline"
        maxWidth="max-w-2xl"
      >
        {formError && (
          <div className="mb-4 p-3 rounded-lg bg-rose-50 border border-rose-200 flex items-start gap-2.5 text-xs text-rose-700">
            <AlertCircle className="w-4 h-4 text-rose-500 flex-shrink-0 mt-0.5" />
            <span>{formError}</span>
          </div>
        )}

        <form onSubmit={handleCreateLead} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Input
              label="First Name"
              name="first_name"
              required
              value={formData.first_name}
              onChange={handleInputChange}
              placeholder="e.g. David"
            />

            <Input
              label="Last Name"
              name="last_name"
              required
              value={formData.last_name}
              onChange={handleInputChange}
              placeholder="e.g. Miller"
            />

            <Input
              label="Lead Email"
              type="email"
              name="email"
              required
              value={formData.email}
              onChange={handleInputChange}
              placeholder="david.miller@company.com"
            />

            <Input
              label="Phone"
              name="phone"
              value={formData.phone}
              onChange={handleInputChange}
              placeholder="+1 (555) 000-0000"
            />

            <Input
              label="Company Name"
              name="company"
              value={formData.company}
              onChange={handleInputChange}
              placeholder="e.g. Apex Global"
            />

            <Input
              label="Job Title"
              name="title"
              value={formData.title}
              onChange={handleInputChange}
              placeholder="e.g. CTO or VP Operations"
            />

            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-700 mb-1.5">
                Lead Source
              </label>
              <select
                name="lead_source"
                value={formData.lead_source}
                onChange={handleInputChange}
                className="w-full text-sm border border-slate-300 rounded-lg p-2.5 bg-white focus:outline-none focus:ring-2 focus:ring-blue-100 focus:border-blue-500"
              >
                {LEAD_SOURCES.map((s) => (
                  <option key={s} value={s}>
                    {s}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-700 mb-1.5">
                Initial Pipeline Stage
              </label>
              <select
                name="lead_status"
                value={formData.lead_status}
                onChange={handleInputChange}
                className="w-full text-sm border border-slate-300 rounded-lg p-2.5 bg-white focus:outline-none focus:ring-2 focus:ring-blue-100 focus:border-blue-500"
              >
                {Object.keys(LEAD_STATUS).map((st) => (
                  <option key={st} value={st}>
                    {LEAD_STATUS[st].label}
                  </option>
                ))}
              </select>
            </div>

            <Input
              label="Lead Score (0 - 100)"
              type="number"
              name="lead_score"
              min="0"
              max="100"
              value={formData.lead_score}
              onChange={handleInputChange}
            />

            <Input
              label="Estimated Deal Value ($)"
              type="number"
              name="estimated_value"
              value={formData.estimated_value}
              onChange={handleInputChange}
              placeholder="e.g. 150000"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-700 mb-1.5">
              Opportunity Notes
            </label>
            <textarea
              name="notes"
              rows="3"
              value={formData.notes}
              onChange={handleInputChange}
              placeholder="Requirements, budget timeline, pain points..."
              className="w-full text-sm border border-slate-300 rounded-lg p-2.5 focus:outline-none focus:ring-2 focus:ring-blue-100 focus:border-blue-500"
            />
          </div>

          <div className="pt-4 border-t border-slate-100 flex items-center justify-end gap-3">
            <Button
              variant="outline"
              onClick={() => setIsAddModalOpen(false)}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              variant="primary"
              isLoading={submitting}
            >
              Add to Pipeline
            </Button>
          </div>
        </form>
      </Modal>

      {/* Convert Lead to Customer Modal */}
      <Modal
        isOpen={!!convertModalLead}
        onClose={() => setConvertModalLead(null)}
        title="Convert Lead to ERP Customer"
        subtitle={`Promote ${convertModalLead?.full_name} (${convertModalLead?.company || 'Lead'}) to an active Customer Account`}
      >
        <form onSubmit={handleConvertLead} className="space-y-4">
          <div className="p-3.5 rounded-xl bg-blue-50 border border-blue-100 text-xs text-blue-800 space-y-1">
            <p className="font-semibold">Conversion Summary:</p>
            <p>&bull; An official Customer record with sequential code (e.g. CUST-100X) will be generated.</p>
            <p>&bull; Interaction history will transfer automatically.</p>
            <p>&bull; Lead status will change to WON.</p>
          </div>

          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-700 mb-1.5">
              Customer Classification Type
            </label>
            <select
              value={convertData.customer_type}
              onChange={(e) => setConvertData({ ...convertData, customer_type: e.target.value })}
              className="w-full text-sm border border-slate-300 rounded-lg p-2.5 bg-white focus:outline-none focus:ring-2 focus:ring-blue-100 focus:border-blue-500"
            >
              <option value="CORPORATE">Corporate</option>
              <option value="ENTERPRISE">Enterprise</option>
              <option value="SMB">SMB</option>
              <option value="INDIVIDUAL">Individual</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-700 mb-1.5">
              Industry
            </label>
            <select
              value={convertData.industry}
              onChange={(e) => setConvertData({ ...convertData, industry: e.target.value })}
              className="w-full text-sm border border-slate-300 rounded-lg p-2.5 bg-white focus:outline-none focus:ring-2 focus:ring-blue-100 focus:border-blue-500"
            >
              <option value="Technology">Technology</option>
              <option value="Manufacturing">Manufacturing</option>
              <option value="Logistics">Logistics</option>
              <option value="Healthcare">Healthcare</option>
              <option value="Finance">Finance</option>
              <option value="Retail">Retail</option>
              <option value="Energy">Energy</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-700 mb-1.5">
              Conversion Note
            </label>
            <textarea
              rows="2"
              value={convertData.create_interaction_note}
              onChange={(e) => setConvertData({ ...convertData, create_interaction_note: e.target.value })}
              className="w-full text-sm border border-slate-300 rounded-lg p-2.5 focus:outline-none focus:ring-2 focus:ring-blue-100 focus:border-blue-500"
            />
          </div>

          <div className="pt-4 border-t border-slate-100 flex items-center justify-end gap-3">
            <Button
              variant="outline"
              onClick={() => setConvertModalLead(null)}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              variant="success"
              isLoading={converting}
              icon={CheckCircle2}
            >
              Confirm &amp; Convert
            </Button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
