import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import {
  Building2,
  Target,
  History,
  TrendingUp,
  Plus,
  ArrowRight,
  Phone,
  Mail,
  Users,
  CheckCircle2,
  Clock,
  Sparkles,
  Calendar,
} from 'lucide-react';
import { crmService } from '../../services/crmService';
import { PageHeader } from '../../components/common/PageHeader';
import { StatCard } from '../../components/common/StatCard';
import { Card } from '../../components/common/Card';
import { Button } from '../../components/common/Button';
import { Badge } from '../../components/common/Badge';
import { formatCurrency, formatDate, formatRelativeTime } from '../../utils/formatters';

export const CRMOverview = () => {
  const [overview, setOverview] = useState({
    customers: { total_customers: 0, active_customers: 0, prospects: 0, total_estimated_revenue: 0 },
    leads: { total_leads: 0, new_leads: 0, qualified_leads: 0, won_leads: 0, pipeline_value: 0, conversion_rate: 0 },
  });
  const [recentActivities, setRecentActivities] = useState([]);
  const [upcomingFollowups, setUpcomingFollowups] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [ovData, acts, fols] = await Promise.all([
          crmService.getOverview(),
          crmService.getInteractions(6),
          crmService.getUpcomingFollowups(5),
        ]);
        setOverview(ovData);
        setRecentActivities(acts);
        setUpcomingFollowups(fols);
      } catch (err) {
        console.error('Error fetching CRM overview:', err);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  return (
    <div className="space-y-6 animate-fade-in">
      <PageHeader
        title="Member 3 — CRM Hub & Operations"
        subtitle="Manage customer relationships, sales leads pipelines, and client interaction history"
        badge={<Badge variant="green" withDot>Functional Module</Badge>}
      >
        <Link to="/crm/customers">
          <Button variant="outline" icon={Building2}>
            Customers
          </Button>
        </Link>
        <Link to="/crm/leads">
          <Button variant="primary" icon={Target}>
            Leads Pipeline
          </Button>
        </Link>
      </PageHeader>

      {/* KPI Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        <StatCard
          title="Total Customers"
          value={loading ? '...' : overview.customers.total_customers}
          subtitle={`${overview.customers.active_customers} Active & ${overview.customers.prospects} Prospects`}
          icon={Building2}
          iconBg="bg-blue-50 text-blue-600"
        />

        <StatCard
          title="Pipeline Leads"
          value={loading ? '...' : overview.leads.total_leads}
          subtitle={`${overview.leads.won_leads} Converted Accounts`}
          icon={Target}
          iconBg="bg-purple-50 text-purple-600"
        />

        <StatCard
          title="Pipeline Value"
          value={loading ? '...' : formatCurrency(overview.leads.pipeline_value)}
          subtitle={`${overview.leads.conversion_rate}% Conversion Rate`}
          icon={TrendingUp}
          iconBg="bg-emerald-50 text-emerald-600"
        />

        <StatCard
          title="Customer Revenue"
          value={loading ? '...' : formatCurrency(overview.customers.total_estimated_revenue)}
          subtitle="Portfolio Value"
          icon={Building2}
          iconBg="bg-amber-50 text-amber-600"
        />
      </div>

      {/* Pipeline Breakdown & Follow-ups */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Sales Pipeline Funnel Overview */}
        <Card
          className="lg:col-span-2"
          title="CRM Pipeline Overview"
          subtitle="Lead stages from initial acquisition to converted customer"
          action={
            <Link to="/crm/leads" className="text-xs font-semibold text-blue-600 hover:text-blue-700">
              Manage Leads &rarr;
            </Link>
          }
        >
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 py-2">
            <div className="p-4 rounded-xl bg-blue-50/70 border border-blue-100 text-center">
              <span className="text-xs font-semibold uppercase text-blue-600">New Leads</span>
              <p className="text-2xl font-bold text-slate-900 mt-1">{overview.leads.new_leads}</p>
              <p className="text-[11px] text-slate-500 mt-0.5">Initial Contact</p>
            </div>

            <div className="p-4 rounded-xl bg-indigo-50/70 border border-indigo-100 text-center">
              <span className="text-xs font-semibold uppercase text-indigo-600">Qualified</span>
              <p className="text-2xl font-bold text-slate-900 mt-1">{overview.leads.qualified_leads}</p>
              <p className="text-[11px] text-slate-500 mt-0.5">Scored &gt; 70</p>
            </div>

            <div className="p-4 rounded-xl bg-emerald-50/70 border border-emerald-100 text-center">
              <span className="text-xs font-semibold uppercase text-emerald-600">Won / Converted</span>
              <p className="text-2xl font-bold text-slate-900 mt-1">{overview.leads.won_leads}</p>
              <p className="text-[11px] text-slate-500 mt-0.5">To Customers</p>
            </div>

            <div className="p-4 rounded-xl bg-amber-50/70 border border-amber-100 text-center">
              <span className="text-xs font-semibold uppercase text-amber-600">Win Rate</span>
              <p className="text-2xl font-bold text-slate-900 mt-1">{overview.leads.conversion_rate}%</p>
              <p className="text-[11px] text-slate-500 mt-0.5">Overall Efficiency</p>
            </div>
          </div>

          <div className="mt-6 pt-4 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
            <span>Automated CRM Workflow connected to Customer Directory</span>
            <Link to="/crm/customers" className="font-semibold text-blue-600 hover:underline">
              View All Customer Accounts &rarr;
            </Link>
          </div>
        </Card>

        {/* Upcoming Follow-up Tasks */}
        <Card
          title="Upcoming Follow-Ups"
          subtitle="Scheduled client calls and demos"
          action={
            <Link to="/crm/history" className="text-xs font-semibold text-blue-600 hover:text-blue-700">
              View All
            </Link>
          }
        >
          {loading ? (
            <p className="text-xs text-slate-400 py-4">Loading follow-ups...</p>
          ) : upcomingFollowups.length === 0 ? (
            <p className="text-xs text-slate-400 py-6 text-center italic">No upcoming follow-ups scheduled.</p>
          ) : (
            <div className="space-y-3">
              {upcomingFollowups.map((fol) => (
                <div
                  key={fol.id}
                  className="p-3 rounded-lg border border-slate-100 bg-slate-50/60 hover:bg-slate-50 transition-colors"
                >
                  <div className="flex items-start justify-between gap-2">
                    <h5 className="text-xs font-bold text-slate-900 line-clamp-1">{fol.title}</h5>
                    <Badge variant="blue" size="sm">
                      {fol.interaction_type}
                    </Badge>
                  </div>
                  <p className="text-[11px] text-slate-500 mt-1 line-clamp-1">{fol.notes || 'Scheduled follow-up'}</p>
                  <div className="flex items-center gap-1.5 text-[10px] text-blue-600 font-medium mt-2">
                    <Calendar className="w-3 h-3" />
                    <span>Due: {formatDate(fol.next_follow_up, true)}</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </Card>
      </div>

      {/* Recent Client Interactions Timeline */}
      <Card
        title="Recent Customer & Lead Activity History"
        subtitle="Chronological audit of calls, emails, meetings, and deals"
        action={
          <Link to="/crm/history">
            <Button size="sm" variant="outline" icon={History}>
              Log Activity
            </Button>
          </Link>
        }
      >
        {loading ? (
          <p className="text-xs text-slate-400 py-4">Loading interactions...</p>
        ) : recentActivities.length === 0 ? (
          <p className="text-xs text-slate-400 py-8 text-center italic">No activities logged yet.</p>
        ) : (
          <div className="divide-y divide-slate-100">
            {recentActivities.map((act) => (
              <div key={act.id} className="py-3.5 flex items-start justify-between gap-4">
                <div className="flex items-start gap-3">
                  <div className="p-2 rounded-lg bg-blue-50 text-blue-600 mt-0.5">
                    {act.interaction_type === 'CALL' ? (
                      <Phone className="w-4 h-4" />
                    ) : act.interaction_type === 'EMAIL' ? (
                      <Mail className="w-4 h-4" />
                    ) : (
                      <Users className="w-4 h-4" />
                    )}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h4 className="text-xs font-bold text-slate-900">{act.title}</h4>
                      <Badge variant="gray" size="sm">
                        {act.interaction_type}
                      </Badge>
                    </div>
                    <p className="text-xs text-slate-600 mt-0.5">{act.notes}</p>
                    <p className="text-[10px] text-slate-400 mt-1">
                      Logged by {act.user_name || 'System User'} &bull; Outcome: {act.outcome || 'Completed'}
                    </p>
                  </div>
                </div>

                <span className="text-[11px] text-slate-400 flex-shrink-0">
                  {formatRelativeTime(act.interaction_date || act.created_at)}
                </span>
              </div>
            ))}
          </div>
        )}
      </Card>
    </div>
  );
};
