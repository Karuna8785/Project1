import React, { useState, useEffect } from 'react';
import {
  History,
  Plus,
  Phone,
  Mail,
  Users,
  FileText,
  CheckSquare,
  TrendingUp,
  Calendar,
  Search,
  Filter,
  AlertCircle,
  User,
} from 'lucide-react';
import { crmService } from '../../services/crmService';
import { useNotification } from '../../hooks/useNotification';
import { PageHeader } from '../../components/common/PageHeader';
import { Card } from '../../components/common/Card';
import { Button } from '../../components/common/Button';
import { Badge } from '../../components/common/Badge';
import { Modal } from '../../components/common/Modal';
import { Input } from '../../components/common/Input';
import { INTERACTION_TYPES } from '../../utils/constants';
import { formatDate, formatRelativeTime } from '../../utils/formatters';

const iconMap = {
  CALL: Phone,
  EMAIL: Mail,
  MEETING: Users,
  NOTE: FileText,
  TASK: CheckSquare,
  DEAL_UPDATE: TrendingUp,
};

export const CustomerHistoryPage = () => {
  const { notifySuccess, notifyError } = useNotification();

  const [interactions, setInteractions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [typeFilter, setTypeFilter] = useState('');

  // Log Activity Modal
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [customers, setCustomers] = useState([]);
  const [leads, setLeads] = useState([]);
  const [targetType, setTargetType] = useState('customer'); // 'customer' | 'lead'
  const [selectedTargetId, setSelectedTargetId] = useState('');

  const [formData, setFormData] = useState({
    interaction_type: 'CALL',
    title: '',
    notes: '',
    outcome: 'COMPLETED',
    next_follow_up: '',
  });

  const fetchInteractions = async () => {
    setLoading(true);
    try {
      const data = await crmService.getInteractions(50);
      setInteractions(data);
    } catch (err) {
      console.error('Error fetching interactions:', err);
      notifyError('Failed to fetch activity history.');
    } finally {
      setLoading(false);
    }
  };

  const loadEntities = async () => {
    try {
      const [cList, lList] = await Promise.all([
        crmService.getCustomers({ limit: 100 }),
        crmService.getLeads({ limit: 100 }),
      ]);
      setCustomers(cList);
      setLeads(lList);
      if (cList.length > 0) setSelectedTargetId(cList[0].id.toString());
    } catch (e) {
      console.error('Error loading targets:', e);
    }
  };

  useEffect(() => {
    fetchInteractions();
    loadEntities();
  }, []);

  const handleCreateInteraction = async (e) => {
    e.preventDefault();
    if (!formData.title.trim() || !selectedTargetId) {
      notifyError('Please complete all required fields.');
      return;
    }

    setSubmitting(true);
    try {
      const payload = {
        interaction_type: formData.interaction_type,
        title: formData.title,
        notes: formData.notes,
        outcome: formData.outcome,
        next_follow_up: formData.next_follow_up ? new Date(formData.next_follow_up).toISOString() : null,
        customer_id: targetType === 'customer' ? parseInt(selectedTargetId) : null,
        lead_id: targetType === 'lead' ? parseInt(selectedTargetId) : null,
      };

      await crmService.logInteraction(payload);
      notifySuccess('Activity recorded successfully!');
      setIsModalOpen(false);
      setFormData({
        interaction_type: 'CALL',
        title: '',
        notes: '',
        outcome: 'COMPLETED',
        next_follow_up: '',
      });
      fetchInteractions();
    } catch (err) {
      notifyError(err.extractedMessage || 'Error logging activity.');
    } finally {
      setSubmitting(false);
    }
  };

  const filtered = interactions.filter((act) => {
    if (!typeFilter) return true;
    return act.interaction_type === typeFilter;
  });

  return (
    <div className="space-y-6 animate-fade-in">
      <PageHeader
        title="Customer Activities & Timeline"
        subtitle="Chronological audit of communication history, calls, meetings, follow-ups, and deal updates"
        badge={<Badge variant="amber">{interactions.length} Entries</Badge>}
      >
        <Button
          variant="primary"
          icon={Plus}
          onClick={() => setIsModalOpen(true)}
        >
          Log Activity
        </Button>
      </PageHeader>

      {/* Filter Chips */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1">
        <button
          type="button"
          onClick={() => setTypeFilter('')}
          className={`px-3 py-1.5 rounded-lg text-xs font-semibold border transition-all ${
            typeFilter === ''
              ? 'bg-slate-900 text-white border-slate-900 shadow-sm'
              : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
          }`}
        >
          All Activities
        </button>

        {INTERACTION_TYPES.map((t) => (
          <button
            key={t.value}
            type="button"
            onClick={() => setTypeFilter(t.value)}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold border transition-all ${
              typeFilter === t.value
                ? 'bg-blue-600 text-white border-blue-600 shadow-sm'
                : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {/* Activities Timeline */}
      <Card noPadding>
        {loading ? (
          <div className="py-16 text-center text-slate-400">Loading timeline...</div>
        ) : filtered.length === 0 ? (
          <div className="py-16 text-center text-slate-400">
            <History className="w-8 h-8 mx-auto text-slate-300 mb-2" />
            <p className="text-sm font-medium">No interactions found for this filter.</p>
          </div>
        ) : (
          <div className="divide-y divide-slate-100 p-6">
            {filtered.map((act) => {
              const Icon = iconMap[act.interaction_type] || FileText;

              return (
                <div key={act.id} className="py-4 first:pt-0 last:pb-0 flex items-start justify-between gap-4">
                  <div className="flex items-start gap-3.5">
                    <div className="p-2.5 rounded-xl bg-blue-50 text-blue-600 border border-blue-100/60 mt-0.5 flex-shrink-0">
                      <Icon className="w-4 h-4" />
                    </div>
                    <div className="space-y-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <h4 className="text-sm font-bold text-slate-900">{act.title}</h4>
                        <Badge variant="blue" size="sm">
                          {act.interaction_type}
                        </Badge>
                        {act.outcome && (
                          <Badge variant="gray" size="sm">
                            {act.outcome}
                          </Badge>
                        )}
                      </div>

                      <p className="text-xs text-slate-600 leading-relaxed max-w-3xl">
                        {act.notes || 'No extra notes.'}
                      </p>

                      <div className="flex items-center gap-3 text-[11px] text-slate-400 pt-1 flex-wrap">
                        <span className="flex items-center gap-1 text-slate-600 font-medium">
                          <User className="w-3 h-3 text-slate-400" />
                          Logged by: {act.user_name || 'System User'}
                        </span>
                        {act.next_follow_up && (
                          <span className="flex items-center gap-1 text-indigo-600 font-semibold">
                            <Calendar className="w-3 h-3" />
                            Next Follow-Up: {formatDate(act.next_follow_up, true)}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>

                  <span className="text-[11px] text-slate-400 whitespace-nowrap flex-shrink-0">
                    {formatDate(act.interaction_date || act.created_at, true)}
                  </span>
                </div>
              );
            })}
          </div>
        )}
      </Card>

      {/* Log Activity Modal */}
      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title="Log Customer or Lead Activity"
        subtitle="Record communication, sales meetings, demo outcomes, and reminders"
      >
        <form onSubmit={handleCreateInteraction} className="space-y-4">
          {/* Target Selector */}
          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-700 mb-1.5">
              Record Associated With
            </label>
            <div className="flex items-center gap-4 mb-2">
              <label className="flex items-center gap-1.5 text-xs text-slate-700 cursor-pointer">
                <input
                  type="radio"
                  name="targetType"
                  value="customer"
                  checked={targetType === 'customer'}
                  onChange={() => {
                    setTargetType('customer');
                    if (customers.length > 0) setSelectedTargetId(customers[0].id.toString());
                  }}
                />
                <span>Customer Account</span>
              </label>
              <label className="flex items-center gap-1.5 text-xs text-slate-700 cursor-pointer">
                <input
                  type="radio"
                  name="targetType"
                  value="lead"
                  checked={targetType === 'lead'}
                  onChange={() => {
                    setTargetType('lead');
                    if (leads.length > 0) setSelectedTargetId(leads[0].id.toString());
                  }}
                />
                <span>Sales Lead</span>
              </label>
            </div>

            <select
              value={selectedTargetId}
              onChange={(e) => setSelectedTargetId(e.target.value)}
              className="w-full text-sm border border-slate-300 rounded-lg p-2.5 bg-white focus:outline-none focus:ring-2 focus:ring-blue-100 focus:border-blue-500"
            >
              {targetType === 'customer'
                ? customers.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name} ({c.customer_code})
                    </option>
                  ))
                : leads.map((l) => (
                    <option key={l.id} value={l.id}>
                      {l.full_name} ({l.company || 'Lead'})
                    </option>
                  ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-700 mb-1.5">
              Activity Type
            </label>
            <div className="grid grid-cols-3 gap-2">
              {INTERACTION_TYPES.map((t) => (
                <button
                  type="button"
                  key={t.value}
                  onClick={() => setFormData({ ...formData, interaction_type: t.value })}
                  className={`px-3 py-2 rounded-lg text-xs font-semibold border transition-all text-center ${
                    formData.interaction_type === t.value
                      ? 'bg-blue-50 border-blue-500 text-blue-700 shadow-sm'
                      : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  {t.label}
                </button>
              ))}
            </div>
          </div>

          <Input
            label="Activity Title"
            required
            value={formData.title}
            onChange={(e) => setFormData({ ...formData, title: e.target.value })}
            placeholder="e.g. Discovery Call with Operations Lead"
          />

          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-700 mb-1.5">
              Notes &amp; Discussion Points
            </label>
            <textarea
              rows="3"
              value={formData.notes}
              onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
              placeholder="Action items, objections, decision makers involved..."
              className="w-full text-sm border border-slate-300 rounded-lg p-2.5 focus:outline-none focus:ring-2 focus:ring-blue-100 focus:border-blue-500"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-700 mb-1.5">
                Outcome Status
              </label>
              <select
                value={formData.outcome}
                onChange={(e) => setFormData({ ...formData, outcome: e.target.value })}
                className="w-full text-sm border border-slate-300 rounded-lg p-2.5 bg-white focus:outline-none focus:ring-2 focus:ring-blue-100 focus:border-blue-500"
              >
                <option value="COMPLETED">Completed</option>
                <option value="FOLLOW_UP_REQUIRED">Follow-up Required</option>
                <option value="PENDING">Pending Response</option>
              </select>
            </div>

            <Input
              label="Next Follow-Up Date"
              type="datetime-local"
              value={formData.next_follow_up}
              onChange={(e) => setFormData({ ...formData, next_follow_up: e.target.value })}
            />
          </div>

          <div className="pt-4 border-t border-slate-100 flex items-center justify-end gap-3">
            <Button
              variant="outline"
              onClick={() => setIsModalOpen(false)}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              variant="primary"
              isLoading={submitting}
            >
              Save Activity Log
            </Button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
