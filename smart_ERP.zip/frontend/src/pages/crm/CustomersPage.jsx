import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  Building2,
  Plus,
  Search,
  Filter,
  Eye,
  Trash2,
  Edit,
  ExternalLink,
  Phone,
  Mail,
  DollarSign,
  AlertCircle,
  CheckCircle2,
} from 'lucide-react';
import { crmService } from '../../services/crmService';
import { useAuth } from '../../hooks/useAuth';
import { useNotification } from '../../hooks/useNotification';
import { PageHeader } from '../../components/common/PageHeader';
import { Card } from '../../components/common/Card';
import { Button } from '../../components/common/Button';
import { Input } from '../../components/common/Input';
import { Table } from '../../components/common/Table';
import { Badge } from '../../components/common/Badge';
import { Modal } from '../../components/common/Modal';
import { CUSTOMER_STATUS, CUSTOMER_TYPES } from '../../utils/constants';
import { formatCurrency, formatDate } from '../../utils/formatters';

export const CustomersPage = () => {
  const navigate = useNavigate();
  const { hasRole } = useAuth();
  const { notifySuccess, notifyError } = useNotification();

  const [customers, setCustomers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [industryFilter, setIndustryFilter] = useState('');

  // Add Customer Modal
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [formError, setFormError] = useState('');
  const [formData, setFormData] = useState({
    name: '',
    company_name: '',
    email: '',
    phone: '',
    website: '',
    industry: 'Technology',
    customer_type: 'CORPORATE',
    status: 'ACTIVE',
    annual_revenue: '',
    credit_limit: '',
    city: '',
    state: '',
    country: 'United States',
    notes: '',
  });

  const fetchCustomers = async () => {
    setLoading(true);
    try {
      const params = {};
      if (search) params.search = search;
      if (statusFilter) params.status = statusFilter;
      if (industryFilter) params.industry = industryFilter;
      const data = await crmService.getCustomers(params);
      setCustomers(data);
    } catch (err) {
      console.error('Error fetching customers:', err);
      notifyError('Failed to fetch customers.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    const delayDebounce = setTimeout(() => {
      fetchCustomers();
    }, 250);
    return () => clearTimeout(delayDebounce);
  }, [search, statusFilter, industryFilter]);

  const handleInputChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
    setFormError('');
  };

  const handleCreateCustomer = async (e) => {
    e.preventDefault();
    if (!formData.name.trim() || !formData.email.trim()) {
      setFormError('Customer Name and Email are required.');
      return;
    }

    setSubmitting(true);
    try {
      const payload = {
        ...formData,
        annual_revenue: formData.annual_revenue ? parseFloat(formData.annual_revenue) : 0,
        credit_limit: formData.credit_limit ? parseFloat(formData.credit_limit) : 0,
      };
      await crmService.createCustomer(payload);
      notifySuccess(`Customer account "${formData.name}" created successfully!`);
      setIsModalOpen(false);
      setFormData({
        name: '',
        company_name: '',
        email: '',
        phone: '',
        website: '',
        industry: 'Technology',
        customer_type: 'CORPORATE',
        status: 'ACTIVE',
        annual_revenue: '',
        credit_limit: '',
        city: '',
        state: '',
        country: 'United States',
        notes: '',
      });
      fetchCustomers();
    } catch (err) {
      const msg = err.extractedMessage || 'Error creating customer account.';
      setFormError(msg);
      notifyError(msg);
    } finally {
      setSubmitting(false);
    }
  };

  const handleDelete = async (id, name, e) => {
    e.stopPropagation();
    if (!window.confirm(`Are you sure you want to delete customer "${name}"?`)) return;

    try {
      await crmService.deleteCustomer(id);
      notifySuccess(`Customer "${name}" deleted.`);
      fetchCustomers();
    } catch (err) {
      notifyError(err.extractedMessage || 'Error deleting customer.');
    }
  };

  const columns = [
    {
      header: 'Customer Code',
      accessor: 'customer_code',
      cellClassName: 'font-mono text-xs font-semibold text-blue-600',
      render: (row) => <span>{row.customer_code}</span>,
    },
    {
      header: 'Customer & Company',
      accessor: 'name',
      render: (row) => (
        <div>
          <p className="font-bold text-slate-900">{row.name}</p>
          <p className="text-xs text-slate-500">{row.company_name || 'Individual'}</p>
        </div>
      ),
    },
    {
      header: 'Contact Info',
      accessor: 'email',
      render: (row) => (
        <div className="space-y-0.5 text-xs">
          <p className="text-slate-700 flex items-center gap-1.5">
            <Mail className="w-3.5 h-3.5 text-slate-400" />
            {row.email}
          </p>
          {row.phone && (
            <p className="text-slate-500 flex items-center gap-1.5">
              <Phone className="w-3.5 h-3.5 text-slate-400" />
              {row.phone}
            </p>
          )}
        </div>
      ),
    },
    {
      header: 'Industry / Type',
      accessor: 'industry',
      render: (row) => (
        <div>
          <Badge variant="blue" size="sm">
            {row.industry || 'Technology'}
          </Badge>
          <p className="text-[10px] text-slate-400 mt-1 uppercase font-semibold">{row.customer_type}</p>
        </div>
      ),
    },
    {
      header: 'Status',
      accessor: 'status',
      render: (row) => {
        const conf = CUSTOMER_STATUS[row.status] || { label: row.status, color: 'gray' };
        return (
          <Badge variant={conf.color} withDot size="sm">
            {conf.label}
          </Badge>
        );
      },
    },
    {
      header: 'Annual Revenue',
      accessor: 'annual_revenue',
      render: (row) => (
        <span className="font-semibold text-slate-900 text-xs">
          {formatCurrency(row.annual_revenue)}
        </span>
      ),
    },
    {
      header: 'Actions',
      accessor: 'actions',
      className: 'text-right',
      cellClassName: 'text-right',
      render: (row) => (
        <div className="flex items-center justify-end gap-1.5" onClick={(e) => e.stopPropagation()}>
          <Link to={`/crm/customers/${row.id}`}>
            <Button size="sm" variant="ghost" className="p-1.5 hover:text-blue-600" title="View Customer Details">
              <Eye className="w-4 h-4" />
            </Button>
          </Link>
          {hasRole(['ADMIN', 'MANAGER']) && (
            <Button
              size="sm"
              variant="ghost"
              className="p-1.5 hover:text-rose-600"
              onClick={(e) => handleDelete(row.id, row.name, e)}
              title="Delete Customer"
            >
              <Trash2 className="w-4 h-4" />
            </Button>
          )}
        </div>
      ),
    },
  ];

  return (
    <div className="space-y-6 animate-fade-in">
      <PageHeader
        title="Customer Directory"
        subtitle="Manage client accounts, contract values, contacts, and interaction history"
        badge={<Badge variant="blue">{customers.length} Accounts</Badge>}
      >
        <Button
          variant="primary"
          icon={Plus}
          onClick={() => setIsModalOpen(true)}
        >
          Add Customer
        </Button>
      </PageHeader>

      {/* Filters & Search Toolbar */}
      <Card noPadding className="p-4 bg-white">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="relative flex-1 w-full">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Search by customer name, company, email, code..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-9 pr-4 py-2 text-xs rounded-lg border border-slate-200 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
            />
          </div>

          <div className="flex items-center gap-2.5 w-full sm:w-auto">
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="text-xs border border-slate-200 rounded-lg px-3 py-2 bg-white text-slate-700 focus:outline-none focus:border-blue-500"
            >
              <option value="">All Statuses</option>
              <option value="ACTIVE">Active</option>
              <option value="PROSPECT">Prospect</option>
              <option value="INACTIVE">Inactive</option>
              <option value="BLOCKED">Blocked</option>
            </select>

            <select
              value={industryFilter}
              onChange={(e) => setIndustryFilter(e.target.value)}
              className="text-xs border border-slate-200 rounded-lg px-3 py-2 bg-white text-slate-700 focus:outline-none focus:border-blue-500"
            >
              <option value="">All Industries</option>
              <option value="Technology">Technology</option>
              <option value="Manufacturing">Manufacturing</option>
              <option value="Logistics">Logistics</option>
              <option value="Healthcare">Healthcare</option>
              <option value="Finance">Finance</option>
            </select>
          </div>
        </div>
      </Card>

      {/* Customer Table */}
      <Card noPadding>
        <Table
          columns={columns}
          data={customers}
          isLoading={loading}
          emptyMessage="No customer accounts found. Click 'Add Customer' to create one."
          onRowClick={(row) => navigate(`/crm/customers/${row.id}`)}
        />
      </Card>

      {/* Add Customer Modal */}
      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title="Add New Customer Account"
        subtitle="Create an enterprise customer account profile"
        maxWidth="max-w-2xl"
      >
        {formError && (
          <div className="mb-4 p-3 rounded-lg bg-rose-50 border border-rose-200 flex items-start gap-2.5 text-xs text-rose-700">
            <AlertCircle className="w-4 h-4 text-rose-500 flex-shrink-0 mt-0.5" />
            <span>{formError}</span>
          </div>
        )}

        <form onSubmit={handleCreateCustomer} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Input
              label="Contact / Primary Name"
              name="name"
              required
              value={formData.name}
              onChange={handleInputChange}
              placeholder="e.g. John Doe or Jane Smith"
            />

            <Input
              label="Company Name"
              name="company_name"
              value={formData.company_name}
              onChange={handleInputChange}
              placeholder="e.g. Acme Corp Ltd"
            />

            <Input
              label="Work Email"
              type="email"
              name="email"
              required
              value={formData.email}
              onChange={handleInputChange}
              placeholder="contact@company.com"
            />

            <Input
              label="Phone Number"
              name="phone"
              value={formData.phone}
              onChange={handleInputChange}
              placeholder="+1 (555) 000-0000"
            />

            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-700 mb-1.5">
                Industry
              </label>
              <select
                name="industry"
                value={formData.industry}
                onChange={handleInputChange}
                className="w-full text-sm border border-slate-300 rounded-lg p-2.5 bg-white focus:outline-none focus:ring-2 focus:ring-blue-100 focus:border-blue-500"
              >
                <option value="Technology">Technology</option>
                <option value="Manufacturing">Manufacturing</option>
                <option value="Logistics">Logistics</option>
                <option value="Healthcare">Healthcare</option>
                <option value="Finance">Finance</option>
                <option value="Retail">Retail</option>
                <option value="Energy">Energy</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-700 mb-1.5">
                Customer Type
              </label>
              <select
                name="customer_type"
                value={formData.customer_type}
                onChange={handleInputChange}
                className="w-full text-sm border border-slate-300 rounded-lg p-2.5 bg-white focus:outline-none focus:ring-2 focus:ring-blue-100 focus:border-blue-500"
              >
                {CUSTOMER_TYPES.map((t) => (
                  <option key={t} value={t}>
                    {t}
                  </option>
                ))}
              </select>
            </div>

            <Input
              label="Annual Revenue ($)"
              type="number"
              name="annual_revenue"
              value={formData.annual_revenue}
              onChange={handleInputChange}
              placeholder="e.g. 500000"
            />

            <Input
              label="Credit Limit ($)"
              type="number"
              name="credit_limit"
              value={formData.credit_limit}
              onChange={handleInputChange}
              placeholder="e.g. 100000"
            />

            <Input
              label="City"
              name="city"
              value={formData.city}
              onChange={handleInputChange}
              placeholder="e.g. San Francisco"
            />

            <Input
              label="State / Region"
              name="state"
              value={formData.state}
              onChange={handleInputChange}
              placeholder="e.g. CA"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-700 mb-1.5">
              Account Notes
            </label>
            <textarea
              name="notes"
              rows="3"
              value={formData.notes}
              onChange={handleInputChange}
              placeholder="Initial onboarding context, special requirements..."
              className="w-full text-sm border border-slate-300 rounded-lg p-2.5 focus:outline-none focus:ring-2 focus:ring-blue-100 focus:border-blue-500"
            />
          </div>

          <div className="pt-4 border-t border-slate-100 flex items-center justify-end gap-3">
            <Button
              variant="outline"
              onClick={() => setIsModalOpen(false)}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              variant="primary"
              isLoading={submitting}
            >
              Create Customer
            </Button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
