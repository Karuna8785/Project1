import React, { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import {
  ArrowLeft,
  Building2,
  Mail,
  Phone,
  Globe,
  MapPin,
  DollarSign,
  Plus,
  History,
  Calendar,
  User,
  Clock,
  MessageSquare,
  AlertCircle,
  FileText,
  PhoneCall,
  Users as UsersIcon,
} from 'lucide-react';
import { crmService } from '../../services/crmService';
import { useNotification } from '../../hooks/useNotification';
import { PageHeader } from '../../components/common/PageHeader';
import { Card } from '../../components/common/Card';
import { Button } from '../../components/common/Button';
import { Badge } from '../../components/common/Badge';
import { Modal } from '../../components/common/Modal';
import { Input } from '../../components/common/Input';
import { CUSTOMER_STATUS, INTERACTION_TYPES } from '../../utils/constants';
import { formatCurrency, formatDate, formatRelativeTime } from '../../utils/formatters';

export const CustomerDetailPage = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { notifySuccess, notifyError } = useNotification();

  const [customer, setCustomer] = useState(null);
  const [loading, setLoading] = useState(true);

  // Interaction Modal
  const [isLogModalOpen, setIsLogModalOpen] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [interactionData, setInteractionData] = useState({
    interaction_type: 'CALL',
    title: '',
    notes: '',
    outcome: 'COMPLETED',
    next_follow_up: '',
  });

  const fetchCustomer = async () => {
    setLoading(true);
    try {
      const data = await crmService.getCustomerById(id);
      setCustomer(data);
    } catch (err) {
      console.error('Error fetching customer:', err);
      notifyError('Failed to load customer profile.');
      navigate('/crm/customers');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (id) {
      fetchCustomer();
    }
  }, [id]);

  const handleLogInteraction = async (e) => {
    e.preventDefault();
    if (!interactionData.title.trim()) {
      notifyError('Please provide a title for the activity.');
      return;
    }

    setSubmitting(true);
    try {
      const payload = {
        customer_id: parseInt(id),
        interaction_type: interactionData.interaction_type,
        title: interactionData.title,
        notes: interactionData.notes,
        outcome: interactionData.outcome,
        next_follow_up: interactionData.next_follow_up ? new Date(interactionData.next_follow_up).toISOString() : null,
      };
      await crmService.logInteraction(payload);
      notifySuccess('Activity logged to customer timeline!');
      setIsLogModalOpen(false);
      setInteractionData({
        interaction_type: 'CALL',
        title: '',
        notes: '',
        outcome: 'COMPLETED',
        next_follow_up: '',
      });
      fetchCustomer();
    } catch (err) {
      notifyError(err.extractedMessage || 'Error logging activity.');
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className="py-24 text-center text-slate-400">
        <p>Loading customer profile...</p>
      </div>
    );
  }

  if (!customer) return null;

  const statusConf = CUSTOMER_STATUS[customer.status] || { label: customer.status, color: 'gray' };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Back button */}
      <div>
        <Link
          to="/crm/customers"
          className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-500 hover:text-slate-900 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Customers</span>
        </Link>
      </div>

      {/* Customer Header Banner */}
      <div className="bg-white rounded-2xl border border-slate-200/80 p-6 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-start gap-4">
          <div className="w-14 h-14 rounded-xl bg-gradient-to-tr from-blue-600 to-indigo-600 flex items-center justify-center text-white font-bold text-xl shadow-md">
            {customer.name.substring(0, 2).toUpperCase()}
          </div>
          <div>
            <div className="flex items-center gap-2.5 flex-wrap">
              <h1 className="text-xl font-bold text-slate-900">{customer.name}</h1>
              <span className="font-mono text-xs px-2 py-0.5 rounded bg-blue-50 text-blue-700 font-bold border border-blue-200">
                {customer.customer_code}
              </span>
              <Badge variant={statusConf.color} withDot size="sm">
                {statusConf.label}
              </Badge>
            </div>
            <p className="text-xs text-slate-500 mt-1 font-medium">
              {customer.company_name || 'Individual Client'} &bull; Industry: {customer.industry} &bull; Type: {customer.customer_type}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2.5 flex-shrink-0">
          <Button
            variant="primary"
            icon={Plus}
            onClick={() => setIsLogModalOpen(true)}
          >
            Log Activity
          </Button>
        </div>
      </div>

      {/* Main Grid: Details + Timeline */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: Account Details & Financials */}
        <div className="space-y-6 lg:col-span-1">
          <Card title="Contact Information">
            <div className="space-y-3.5 text-xs">
              <div className="flex items-center justify-between">
                <span className="text-slate-400 flex items-center gap-2">
                  <Mail className="w-4 h-4" /> Email
                </span>
                <span className="font-medium text-slate-900">{customer.email}</span>
              </div>

              <div className="flex items-center justify-between">
                <span className="text-slate-400 flex items-center gap-2">
                  <Phone className="w-4 h-4" /> Phone
                </span>
                <span className="font-medium text-slate-900">{customer.phone || '—'}</span>
              </div>

              <div className="flex items-center justify-between">
                <span className="text-slate-400 flex items-center gap-2">
                  <Globe className="w-4 h-4" /> Website
                </span>
                {customer.website ? (
                  <a
                    href={customer.website}
                    target="_blank"
                    rel="noreferrer"
                    className="text-blue-600 hover:underline truncate max-w-[150px]"
                  >
                    {customer.website}
                  </a>
                ) : (
                  <span className="text-slate-400">—</span>
                )}
              </div>

              <div className="flex items-center justify-between">
                <span className="text-slate-400 flex items-center gap-2">
                  <MapPin className="w-4 h-4" /> Location
                </span>
                <span className="font-medium text-slate-900">
                  {[customer.city, customer.state, customer.country].filter(Boolean).join(', ') || '—'}
                </span>
              </div>
            </div>
          </Card>

          <Card title="Financial Profile">
            <div className="space-y-4 text-xs">
              <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-100">
                <span className="text-slate-500 font-medium">Annual Revenue</span>
                <p className="text-lg font-bold text-slate-900 mt-0.5">
                  {formatCurrency(customer.annual_revenue)}
                </p>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-100">
                <span className="text-slate-500 font-medium">ERP Credit Limit</span>
                <p className="text-lg font-bold text-slate-900 mt-0.5">
                  {formatCurrency(customer.credit_limit)}
                </p>
              </div>

              {customer.notes && (
                <div className="pt-2">
                  <span className="text-slate-400 font-semibold uppercase text-[10px] tracking-wider block mb-1">
                    Notes
                  </span>
                  <p className="text-slate-600 bg-slate-50 p-2.5 rounded-lg border border-slate-100 text-xs">
                    {customer.notes}
                  </p>
                </div>
              )}
            </div>
          </Card>
        </div>

        {/* Right Column: Interaction History Timeline */}
        <div className="lg:col-span-2 space-y-6">
          <Card
            title="Customer Interaction Timeline"
            subtitle="Complete record of phone calls, meetings, emails, and account notes"
            action={
              <Button
                size="sm"
                variant="outline"
                icon={Plus}
                onClick={() => setIsLogModalOpen(true)}
              >
                Add Entry
              </Button>
            }
          >
            {customer.interactions?.length === 0 ? (
              <div className="py-12 text-center text-slate-400 space-y-2">
                <History className="w-8 h-8 mx-auto text-slate-300" />
                <p className="text-sm font-medium">No activity history logged yet.</p>
                <p className="text-xs">Click "Log Activity" to record your first client conversation.</p>
              </div>
            ) : (
              <div className="relative pl-6 border-l-2 border-slate-100 space-y-6 my-2">
                {customer.interactions?.map((act) => (
                  <div key={act.id} className="relative group">
                    {/* Timeline Node Dot */}
                    <div className="absolute -left-[31px] top-1 w-4 h-4 rounded-full bg-blue-600 border-2 border-white shadow-sm" />

                    <div className="p-4 rounded-xl border border-slate-100 bg-slate-50/50 hover:bg-slate-50 transition-colors">
                      <div className="flex items-start justify-between gap-3">
                        <div>
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="text-xs font-bold text-slate-900">{act.title}</span>
                            <Badge variant="blue" size="sm">
                              {act.interaction_type}
                            </Badge>
                            {act.outcome && (
                              <Badge variant="gray" size="sm">
                                {act.outcome}
                              </Badge>
                            )}
                          </div>
                          <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                            {act.notes || 'No extra notes recorded.'}
                          </p>
                        </div>
                        <span className="text-[11px] text-slate-400 whitespace-nowrap">
                          {formatDate(act.interaction_date || act.created_at, true)}
                        </span>
                      </div>

                      {act.next_follow_up && (
                        <div className="mt-3 pt-2.5 border-t border-slate-200/60 flex items-center gap-2 text-[11px] text-indigo-600 font-semibold">
                          <Calendar className="w-3.5 h-3.5" />
                          <span>Next Follow-Up: {formatDate(act.next_follow_up, true)}</span>
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </Card>
        </div>
      </div>

      {/* Log Activity Modal */}
      <Modal
        isOpen={isLogModalOpen}
        onClose={() => setIsLogModalOpen(false)}
        title="Log Client Interaction"
        subtitle={`Record communication for ${customer.name}`}
      >
        <form onSubmit={handleLogInteraction} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-700 mb-1.5">
              Activity Type
            </label>
            <div className="grid grid-cols-3 gap-2">
              {INTERACTION_TYPES.map((t) => (
                <button
                  type="button"
                  key={t.value}
                  onClick={() => setInteractionData({ ...interactionData, interaction_type: t.value })}
                  className={`px-3 py-2 rounded-lg text-xs font-semibold border transition-all text-center ${
                    interactionData.interaction_type === t.value
                      ? 'bg-blue-50 border-blue-500 text-blue-700 shadow-sm'
                      : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  {t.label}
                </button>
              ))}
            </div>
          </div>

          <Input
            label="Activity Summary / Title"
            required
            value={interactionData.title}
            onChange={(e) => setInteractionData({ ...interactionData, title: e.target.value })}
            placeholder="e.g. Discussed Q3 contract terms with VP"
          />

          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-700 mb-1.5">
              Detailed Notes
            </label>
            <textarea
              rows="3"
              value={interactionData.notes}
              onChange={(e) => setInteractionData({ ...interactionData, notes: e.target.value })}
              placeholder="Action items, objections, requirements discussed..."
              className="w-full text-sm border border-slate-300 rounded-lg p-2.5 focus:outline-none focus:ring-2 focus:ring-blue-100 focus:border-blue-500"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-700 mb-1.5">
                Outcome Status
              </label>
              <select
                value={interactionData.outcome}
                onChange={(e) => setInteractionData({ ...interactionData, outcome: e.target.value })}
                className="w-full text-sm border border-slate-300 rounded-lg p-2.5 bg-white focus:outline-none focus:ring-2 focus:ring-blue-100 focus:border-blue-500"
              >
                <option value="COMPLETED">Completed</option>
                <option value="FOLLOW_UP_REQUIRED">Follow-up Required</option>
                <option value="PENDING">Pending Response</option>
              </select>
            </div>

            <Input
              label="Next Follow-Up Date"
              type="datetime-local"
              value={interactionData.next_follow_up}
              onChange={(e) => setInteractionData({ ...interactionData, next_follow_up: e.target.value })}
            />
          </div>

          <div className="pt-4 border-t border-slate-100 flex items-center justify-end gap-3">
            <Button
              variant="outline"
              onClick={() => setIsLogModalOpen(false)}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              variant="primary"
              isLoading={submitting}
            >
              Save Activity
            </Button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
