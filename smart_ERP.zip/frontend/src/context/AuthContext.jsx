import React, { createContext, useState, useEffect, useCallback } from 'react';
import { authService } from '../services/authService';
import { tokenStorage } from '../utils/tokenStorage';

export const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(tokenStorage.getUser());
  const [token, setToken] = useState(tokenStorage.getToken());
  const [loading, setLoading] = useState(true);

  // Initialize auth state by fetching fresh profile from /auth/me if token exists
  useEffect(() => {
    const initAuth = async () => {
      const storedToken = tokenStorage.getToken();
      if (storedToken) {
        try {
          const userData = await authService.getMe();
          setUser(userData);
          tokenStorage.setUser(userData);
        } catch (err) {
          console.warn('Session expired or invalid:', err);
          tokenStorage.clearAll();
          setUser(null);
          setToken(null);
        }
      } else {
        tokenStorage.clearAll();
        setUser(null);
        setToken(null);
      }
      setLoading(false);
    };

    initAuth();
  }, []);

  const login = useCallback(async (usernameOrEmail, password) => {
    setLoading(true);
    try {
      const data = await authService.login(usernameOrEmail, password);
      const accessToken = data.access_token;
      const userProfile = data.user;

      tokenStorage.setToken(accessToken);
      tokenStorage.setUser(userProfile);
      setToken(accessToken);
      setUser(userProfile);
      return userProfile;
    } finally {
      setLoading(false);
    }
  }, []);

  const register = useCallback(async (userData) => {
    setLoading(true);
    try {
      const result = await authService.register(userData);
      return result;
    } finally {
      setLoading(false);
    }
  }, []);

  const logout = useCallback(async () => {
    try {
      await authService.logout();
    } catch (e) {
      console.error('Logout error:', e);
    } finally {
      tokenStorage.clearAll();
      setUser(null);
      setToken(null);
    }
  }, []);

  const refreshProfile = useCallback(async () => {
    try {
      const userData = await authService.getMe();
      setUser(userData);
      tokenStorage.setUser(userData);
      return userData;
    } catch (e) {
      console.error('Failed to refresh user profile:', e);
      return null;
    }
  }, []);

  const hasRole = useCallback((roleOrRoles) => {
    if (!user) return false;
    if (user.is_superuser || (user.roles && user.roles.includes('ADMIN')) || user.role === 'ADMIN') {
      return true;
    }
    const rolesToCheck = Array.isArray(roleOrRoles) ? roleOrRoles : [roleOrRoles];
    const userRoles = user.roles || [user.role];
    return rolesToCheck.some((r) => userRoles.map((ur) => ur.toUpperCase()).includes(r.toUpperCase()));
  }, [user]);

  const hasPermission = useCallback((permissionCode) => {
    if (!user) return false;
    if (user.is_superuser || (user.roles && user.roles.includes('ADMIN')) || user.role === 'ADMIN') {
      return true;
    }
    const userPerms = user.permissions || [];
    return userPerms.includes(permissionCode);
  }, [user]);

  const value = {
    user,
    token,
    loading,
    isAuthenticated: !!token && !!user,
    role: user ? user.role : null,
    roles: user ? (user.roles || [user.role]) : [],
    permissions: user ? (user.permissions || []) : [],
    login,
    register,
    logout,
    refreshProfile,
    hasRole,
    hasPermission,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};
