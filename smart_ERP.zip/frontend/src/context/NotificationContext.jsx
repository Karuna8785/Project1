import React, { createContext, useState, useCallback } from 'react';

export const NotificationContext = createContext(null);

export const NotificationProvider = ({ children }) => {
  const [toasts, setToasts] = useState([]);

  const removeToast = useCallback((id) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  const addToast = useCallback((message, type = 'info', duration = 4500) => {
    const id = `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    const newToast = { id, message, type };

    setToasts((prev) => [...prev, newToast]);

    if (duration > 0) {
      setTimeout(() => {
        removeToast(id);
      }, duration);
    }
  }, [removeToast]);

  const notifySuccess = useCallback((msg, duration) => addToast(msg, 'success', duration), [addToast]);
  const notifyError = useCallback((msg, duration) => addToast(msg, 'error', duration), [addToast]);
  const notifyInfo = useCallback((msg, duration) => addToast(msg, 'info', duration), [addToast]);
  const notifyWarning = useCallback((msg, duration) => addToast(msg, 'warning', duration), [addToast]);

  return (
    <NotificationContext.Provider
      value={{
        toasts,
        addToast,
        removeToast,
        notifySuccess,
        notifyError,
        notifyInfo,
        notifyWarning,
      }}
    >
      {children}
    </NotificationContext.Provider>
  );
};
