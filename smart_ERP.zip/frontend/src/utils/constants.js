export const ROLES = {
  ADMIN: 'ADMIN',
  MANAGER: 'MANAGER',
  EMPLOYEE: 'EMPLOYEE',
};

export const CUSTOMER_STATUS = {
  ACTIVE: { label: 'Active', color: 'green' },
  INACTIVE: { label: 'Inactive', color: 'gray' },
  PROSPECT: { label: 'Prospect', color: 'blue' },
  BLOCKED: { label: 'Blocked', color: 'red' },
};

export const CUSTOMER_TYPES = [
  'INDIVIDUAL',
  'CORPORATE',
  'ENTERPRISE',
  'SMB',
];

export const LEAD_STATUS = {
  NEW: { label: 'New Lead', color: 'blue' },
  CONTACTED: { label: 'Contacted', color: 'purple' },
  QUALIFIED: { label: 'Qualified', color: 'indigo' },
  PROPOSAL_SENT: { label: 'Proposal Sent', color: 'amber' },
  NEGOTIATION: { label: 'Negotiation', color: 'orange' },
  WON: { label: 'Won / Converted', color: 'green' },
  LOST: { label: 'Lost', color: 'red' },
};

export const LEAD_SOURCES = [
  'WEBSITE',
  'REFERRAL',
  'COLD_CALL',
  'CAMPAIGN',
  'PARTNER',
  'OTHER',
];

export const INTERACTION_TYPES = [
  { value: 'CALL', label: 'Phone Call', icon: 'Phone' },
  { value: 'EMAIL', label: 'Email', icon: 'Mail' },
  { value: 'MEETING', label: 'Meeting / Demo', icon: 'Users' },
  { value: 'NOTE', label: 'Note / Note Log', icon: 'FileText' },
  { value: 'TASK', label: 'Task / Follow-up', icon: 'CheckSquare' },
  { value: 'DEAL_UPDATE', label: 'Deal Update', icon: 'TrendingUp' },
];

export const MODULE_NAVIGATION = [
  {
    category: 'Core',
    items: [
      { name: 'Dashboard', path: '/dashboard', icon: 'LayoutDashboard', member: 'Member 7 / Overview', status: 'active' },
      { name: 'Security Audit', path: '/audit-logs', icon: 'ShieldAlert', member: 'Member 1', status: 'active', roleRequired: ['ADMIN', 'MANAGER'] },
      { name: 'User Management', path: '/users', icon: 'UserCheck', member: 'Member 1', status: 'active', roleRequired: ['ADMIN', 'MANAGER'] },
    ]
  },
  {
    category: 'Member 3 — CRM (Active)',
    items: [
      { name: 'CRM Overview', path: '/crm', icon: 'TrendingUp', member: 'Member 3', status: 'active' },
      { name: 'Customers', path: '/crm/customers', icon: 'Building2', member: 'Member 3', status: 'active' },
      { name: 'Leads Pipeline', path: '/crm/leads', icon: 'Target', member: 'Member 3', status: 'active' },
      { name: 'Activities & Timeline', path: '/crm/history', icon: 'History', member: 'Member 3', status: 'active' },
    ]
  },
  {
    category: 'Future ERP Modules',
    items: [
      { name: 'HR Management', path: '/hr', icon: 'Users', member: 'Member 2', status: 'upcoming' },
      { name: 'Inventory Control', path: '/inventory', icon: 'Package', member: 'Member 4', status: 'upcoming' },
      { name: 'Sales & Invoicing', path: '/sales', icon: 'ShoppingBag', member: 'Member 5', status: 'upcoming' },
      { name: 'Procurement', path: '/procurement', icon: 'Truck', member: 'Member 6', status: 'upcoming' },
      { name: 'Finance & Accounts', path: '/finance', icon: 'Landmark', member: 'Member 6', status: 'upcoming' },
      { name: 'Reports & Analytics', path: '/reports', icon: 'BarChart3', member: 'Member 7', status: 'upcoming' },
    ]
  }
];
