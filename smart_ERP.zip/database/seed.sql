-- ============================================================================
-- SmartERP Initial Seed SQL Script
-- ============================================================================

-- 1. Insert Default Permissions
INSERT INTO permissions (code, name, description, module) VALUES
('AUTH_LOGIN', 'Login to system', 'Allows user authentication', 'AUTH'),
('AUTH_REGISTER', 'Register new account', 'Allows user self-registration', 'AUTH'),
('AUTH_LOGOUT', 'Logout session', 'Terminates active user session', 'AUTH'),
('USER_CREATE', 'Create system user', 'Create user accounts', 'USERS'),
('USER_READ', 'View users', 'Read system user profiles', 'USERS'),
('USER_UPDATE', 'Modify user', 'Update user account parameters', 'USERS'),
('USER_DELETE', 'Delete user', 'Deactivate or delete user account', 'USERS'),
('ROLE_CREATE', 'Create role', 'Create security role', 'ROLES'),
('ROLE_READ', 'View roles', 'Inspect system roles and permissions', 'ROLES'),
('ROLE_UPDATE', 'Update role', 'Update role definitions', 'ROLES'),
('ROLE_DELETE', 'Delete role', 'Remove system role', 'ROLES'),
('AUDIT_LOG_READ', 'View audit logs', 'Inspect security audit events', 'AUDIT'),
('CRM_CUSTOMER_CREATE', 'Create customer', 'Create new customer records', 'CRM'),
('CRM_CUSTOMER_READ', 'View customer', 'View customer details and history', 'CRM'),
('CRM_CUSTOMER_UPDATE', 'Update customer', 'Update customer parameters', 'CRM'),
('CRM_CUSTOMER_DELETE', 'Delete customer', 'Delete customer records', 'CRM'),
('CRM_LEAD_CREATE', 'Create lead', 'Create sales opportunities', 'CRM'),
('CRM_LEAD_READ', 'View lead', 'Inspect sales leads pipeline', 'CRM'),
('CRM_LEAD_UPDATE', 'Update lead', 'Modify lead stage and values', 'CRM'),
('CRM_LEAD_DELETE', 'Delete lead', 'Delete sales leads', 'CRM'),
('CRM_INTERACTION_CREATE', 'Log interaction', 'Log client calls and meetings', 'CRM'),
('CRM_INTERACTION_READ', 'View interaction', 'Read interaction timeline', 'CRM')
ON CONFLICT (code) DO NOTHING;

-- 2. Insert Default Roles
INSERT INTO roles (name, description, is_default) VALUES
('ADMIN', 'Full system administrator with unrestricted access', FALSE),
('MANAGER', 'Operational manager with CRM and team oversight', FALSE),
('EMPLOYEE', 'Standard employee user with regular operational access', TRUE)
ON CONFLICT (name) DO NOTHING;
