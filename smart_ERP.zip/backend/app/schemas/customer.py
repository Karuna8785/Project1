from datetime import datetime
from typing import Optional, List
from decimal import Decimal
from pydantic import BaseModel, EmailStr, Field
from app.schemas.customer_history import CustomerHistoryOut


class CustomerBase(BaseModel):
    name: str = Field(..., min_length=2, max_length=150)
    company_name: Optional[str] = None
    email: EmailStr
    phone: Optional[str] = None
    website: Optional[str] = None
    industry: Optional[str] = "Technology"
    customer_type: str = Field(default="CORPORATE", description="INDIVIDUAL, CORPORATE, ENTERPRISE, SMB")
    status: str = Field(default="ACTIVE", description="ACTIVE, INACTIVE, PROSPECT, BLOCKED")
    address_line1: Optional[str] = None
    address_line2: Optional[str] = None
    city: Optional[str] = None
    state: Optional[str] = None
    postal_code: Optional[str] = None
    country: Optional[str] = "United States"
    annual_revenue: Optional[Decimal] = Decimal("0.00")
    credit_limit: Optional[Decimal] = Decimal("0.00")
    notes: Optional[str] = None
    assigned_to_id: Optional[int] = None


class CustomerCreate(CustomerBase):
    customer_code: Optional[str] = None  # If not provided, will be auto-generated e.g. CUST-1001


class CustomerUpdate(BaseModel):
    name: Optional[str] = None
    company_name: Optional[str] = None
    email: Optional[EmailStr] = None
    phone: Optional[str] = None
    website: Optional[str] = None
    industry: Optional[str] = None
    customer_type: Optional[str] = None
    status: Optional[str] = None
    address_line1: Optional[str] = None
    address_line2: Optional[str] = None
    city: Optional[str] = None
    state: Optional[str] = None
    postal_code: Optional[str] = None
    country: Optional[str] = None
    annual_revenue: Optional[Decimal] = None
    credit_limit: Optional[Decimal] = None
    notes: Optional[str] = None
    assigned_to_id: Optional[int] = None


class CustomerOut(CustomerBase):
    id: int
    customer_code: str
    assigned_to_name: Optional[str] = None
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True

    @classmethod
    def from_orm_custom(cls, c):
        return cls(
            id=c.id,
            customer_code=c.customer_code,
            name=c.name,
            company_name=c.company_name,
            email=c.email,
            phone=c.phone,
            website=c.website,
            industry=c.industry,
            customer_type=c.customer_type,
            status=c.status,
            address_line1=c.address_line1,
            address_line2=c.address_line2,
            city=c.city,
            state=c.state,
            postal_code=c.postal_code,
            country=c.country,
            annual_revenue=c.annual_revenue,
            credit_limit=c.credit_limit,
            notes=c.notes,
            assigned_to_id=c.assigned_to_id,
            assigned_to_name=c.assigned_to.full_name if c.assigned_to else None,
            created_at=c.created_at,
            updated_at=c.updated_at,
        )


class CustomerDetailOut(CustomerOut):
    interactions: List[CustomerHistoryOut] = []


class CustomerStats(BaseModel):
    total_customers: int
    active_customers: int
    prospects: int
    total_estimated_revenue: Decimal
