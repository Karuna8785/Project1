from datetime import datetime
from typing import Optional, List
from pydantic import BaseModel, Field
from app.schemas.permission import PermissionOut


class RoleBase(BaseModel):
    name: str = Field(..., max_length=50)
    description: Optional[str] = None
    is_default: bool = False


class RoleCreate(RoleBase):
    permission_ids: Optional[List[int]] = []


class RoleUpdate(BaseModel):
    name: Optional[str] = Field(None, max_length=50)
    description: Optional[str] = None
    is_default: Optional[bool] = None
    permission_ids: Optional[List[int]] = None


class RoleOut(RoleBase):
    id: int
    created_at: datetime
    permissions: List[PermissionOut] = []

    class Config:
        from_attributes = True

    @classmethod
    def from_orm_with_permissions(cls, role):
        perms = [rp.permission for rp in role.permissions if rp.permission]
        return cls(
            id=role.id,
            name=role.name,
            description=role.description,
            is_default=role.is_default,
            created_at=role.created_at,
            permissions=[PermissionOut.model_validate(p) for p in perms]
        )
