from datetime import datetime
from typing import Optional
from pydantic import BaseModel


class AuditLogBase(BaseModel):
    action: str
    entity_type: Optional[str] = None
    entity_id: Optional[str] = None
    ip_address: Optional[str] = None
    user_agent: Optional[str] = None
    details: Optional[str] = None


class AuditLogCreate(AuditLogBase):
    user_id: Optional[int] = None
    user_email: Optional[str] = None


class AuditLogOut(AuditLogBase):
    id: int
    user_id: Optional[int] = None
    user_email: Optional[str] = None
    created_at: datetime

    class Config:
        from_attributes = True
