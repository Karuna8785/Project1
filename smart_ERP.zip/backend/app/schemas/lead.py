from datetime import datetime
from typing import Optional, List
from decimal import Decimal
from pydantic import BaseModel, EmailStr, Field
from app.schemas.customer_history import CustomerHistoryOut


class LeadBase(BaseModel):
    first_name: str = Field(..., min_length=1, max_length=100)
    last_name: str = Field(..., min_length=1, max_length=100)
    email: EmailStr
    phone: Optional[str] = None
    company: Optional[str] = None
    title: Optional[str] = None
    lead_source: str = Field(default="WEBSITE", description="WEBSITE, REFERRAL, COLD_CALL, CAMPAIGN, PARTNER, OTHER")
    lead_status: str = Field(default="NEW", description="NEW, CONTACTED, QUALIFIED, PROPOSAL_SENT, NEGOTIATION, WON, LOST")
    lead_score: int = Field(default=50, ge=0, le=100)
    estimated_value: Decimal = Field(default=Decimal("0.00"))
    notes: Optional[str] = None
    assigned_to_id: Optional[int] = None


class LeadCreate(LeadBase):
    pass


class LeadUpdate(BaseModel):
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    email: Optional[EmailStr] = None
    phone: Optional[str] = None
    company: Optional[str] = None
    title: Optional[str] = None
    lead_source: Optional[str] = None
    lead_status: Optional[str] = None
    lead_score: Optional[int] = Field(None, ge=0, le=100)
    estimated_value: Optional[Decimal] = None
    notes: Optional[str] = None
    assigned_to_id: Optional[int] = None


class LeadConvertRequest(BaseModel):
    customer_name: Optional[str] = None
    customer_type: str = "CORPORATE"
    industry: Optional[str] = "Technology"
    create_interaction_note: Optional[str] = "Converted from Lead"


class LeadOut(LeadBase):
    id: int
    full_name: str
    assigned_to_name: Optional[str] = None
    converted_customer_id: Optional[int] = None
    converted_at: Optional[datetime] = None
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True

    @classmethod
    def from_orm_custom(cls, l):
        return cls(
            id=l.id,
            first_name=l.first_name,
            last_name=l.last_name,
            full_name=l.full_name,
            email=l.email,
            phone=l.phone,
            company=l.company,
            title=l.title,
            lead_source=l.lead_source,
            lead_status=l.lead_status,
            lead_score=l.lead_score,
            estimated_value=l.estimated_value,
            notes=l.notes,
            assigned_to_id=l.assigned_to_id,
            assigned_to_name=l.assigned_to.full_name if l.assigned_to else None,
            converted_customer_id=l.converted_customer_id,
            converted_at=l.converted_at,
            created_at=l.created_at,
            updated_at=l.updated_at,
        )


class LeadDetailOut(LeadOut):
    interactions: List[CustomerHistoryOut] = []


class LeadPipelineStats(BaseModel):
    total_leads: int
    new_leads: int
    qualified_leads: int
    won_leads: int
    conversion_rate: float
    pipeline_value: Decimal
