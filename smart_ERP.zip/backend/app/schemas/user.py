from datetime import datetime
from typing import Optional, List
from pydantic import BaseModel, EmailStr, Field
from app.schemas.role import RoleOut


class UserBase(BaseModel):
    email: EmailStr
    username: str
    full_name: str
    is_active: bool = True
    is_superuser: bool = False


class UserCreate(UserBase):
    password: str = Field(..., min_length=6)
    role_names: Optional[List[str]] = ["EMPLOYEE"]


class UserUpdate(BaseModel):
    full_name: Optional[str] = None
    email: Optional[EmailStr] = None
    is_active: Optional[bool] = None
    password: Optional[str] = None
    role_names: Optional[List[str]] = None


class UserOut(UserBase):
    id: int
    created_at: datetime
    role: str
    roles: List[str]
    permissions: List[str]

    class Config:
        from_attributes = True

    @classmethod
    def from_orm_custom(cls, user):
        return cls(
            id=user.id,
            email=user.email,
            username=user.username,
            full_name=user.full_name,
            is_active=user.is_active,
            is_superuser=user.is_superuser,
            created_at=user.created_at,
            role=user.primary_role,
            roles=user.role_names,
            permissions=user.permissions,
        )


class UserRoleAssignRequest(BaseModel):
    role_ids: List[int]
