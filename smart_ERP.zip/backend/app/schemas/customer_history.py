from datetime import datetime
from typing import Optional
from pydantic import BaseModel, Field


class CustomerHistoryBase(BaseModel):
    customer_id: Optional[int] = None
    lead_id: Optional[int] = None
    interaction_type: str = Field(..., description="CALL, EMAIL, MEETING, NOTE, TASK, STATUS_CHANGE, DEAL_UPDATE")
    title: str = Field(..., min_length=2, max_length=200)
    notes: Optional[str] = None
    outcome: Optional[str] = None
    interaction_date: Optional[datetime] = None
    next_follow_up: Optional[datetime] = None


class CustomerHistoryCreate(CustomerHistoryBase):
    pass


class CustomerHistoryUpdate(BaseModel):
    title: Optional[str] = None
    notes: Optional[str] = None
    outcome: Optional[str] = None
    interaction_date: Optional[datetime] = None
    next_follow_up: Optional[datetime] = None


class CustomerHistoryOut(CustomerHistoryBase):
    id: int
    user_id: Optional[int] = None
    user_name: Optional[str] = None
    created_at: datetime

    class Config:
        from_attributes = True

    @classmethod
    def from_orm_custom(cls, hist):
        return cls(
            id=hist.id,
            customer_id=hist.customer_id,
            lead_id=hist.lead_id,
            user_id=hist.user_id,
            user_name=hist.user.full_name if hist.user else None,
            interaction_type=hist.interaction_type,
            title=hist.title,
            notes=hist.notes,
            outcome=hist.outcome,
            interaction_date=hist.interaction_date,
            next_follow_up=hist.next_follow_up,
            created_at=hist.created_at
        )
