from datetime import datetime
from typing import Optional
from pydantic import BaseModel, Field


class PermissionBase(BaseModel):
    code: str = Field(..., max_length=100)
    name: str = Field(..., max_length=150)
    description: Optional[str] = None
    module: str = Field(default="AUTH", max_length=50)


class PermissionCreate(PermissionBase):
    pass


class PermissionOut(PermissionBase):
    id: int
    created_at: datetime

    class Config:
        from_attributes = True
