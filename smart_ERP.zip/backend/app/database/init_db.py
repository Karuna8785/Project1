import logging
from app.database.session import Base, engine
from app.database.seed import seed_database

logger = logging.getLogger("smarterp.init_db")


def init_db():
    logger.info("Initializing database tables...")
    Base.metadata.create_all(bind=engine)
    logger.info("Tables created. Running seed...")
    seed_database()
    logger.info("Database initialization complete.")


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    init_db()
