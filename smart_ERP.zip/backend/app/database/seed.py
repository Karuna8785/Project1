import logging
from datetime import datetime, timezone, timedelta
from decimal import Decimal
from sqlalchemy.orm import Session
from app.database.session import SessionLocal, Base, engine
from app.models.permission import Permission
from app.models.role import Role, RolePermission, UserRole
from app.models.user import User
from app.models.customer import Customer
from app.models.lead import Lead
from app.models.customer_history import CustomerHistory
from app.core.security import get_password_hash
from app.core.config import settings

logger = logging.getLogger("smarterp.seed")


def seed_database(db: Session = None):
    close_db = False
    if db is None:
        db = SessionLocal()
        close_db = True

    try:
        # Create all tables if not exist
        Base.metadata.create_all(bind=engine)

        # 1. PERMISSIONS
        permissions_data = [
            # Authentication
            ("AUTH_LOGIN", "Login to system", "AUTH"),
            ("AUTH_REGISTER", "Register new account", "AUTH"),
            ("AUTH_LOGOUT", "Logout and terminate session", "AUTH"),
            # User Management
            ("USER_CREATE", "Create system user", "USERS"),
            ("USER_READ", "View user profiles", "USERS"),
            ("USER_UPDATE", "Modify user details and roles", "USERS"),
            ("USER_DELETE", "Deactivate or delete user", "USERS"),
            # Role Management
            ("ROLE_CREATE", "Create custom roles", "ROLES"),
            ("ROLE_READ", "View roles and assigned permissions", "ROLES"),
            ("ROLE_UPDATE", "Update role details and permissions", "ROLES"),
            ("ROLE_DELETE", "Delete role", "ROLES"),
            # Audit Logs
            ("AUDIT_LOG_READ", "View security audit events", "AUDIT"),
            # CRM Module Permissions (Member 3)
            ("CRM_CUSTOMER_CREATE", "Create customer accounts", "CRM"),
            ("CRM_CUSTOMER_READ", "View customer details and history", "CRM"),
            ("CRM_CUSTOMER_UPDATE", "Update customer profiles and limits", "CRM"),
            ("CRM_CUSTOMER_DELETE", "Delete customer records", "CRM"),
            ("CRM_LEAD_CREATE", "Create sales leads", "CRM"),
            ("CRM_LEAD_READ", "View pipeline leads and score", "CRM"),
            ("CRM_LEAD_UPDATE", "Update lead stage and status", "CRM"),
            ("CRM_LEAD_DELETE", "Delete leads", "CRM"),
            ("CRM_INTERACTION_CREATE", "Log customer interactions and calls", "CRM"),
            ("CRM_INTERACTION_READ", "View customer interaction timeline", "CRM"),
            # Future Module Stubs
            ("EMPLOYEE_CREATE", "Create employee profile (Future HR)", "HR"),
            ("PRODUCT_CREATE", "Create product SKU (Future Inventory)", "INVENTORY"),
            ("INVOICE_CREATE", "Generate sales invoice (Future Sales)", "SALES"),
            ("PURCHASE_CREATE", "Create purchase order (Future Procurement)", "PROCUREMENT"),
            ("REPORT_VIEW", "View business analytics (Future Reports)", "REPORTS"),
        ]

        permission_map = {}
        for code, name, module in permissions_data:
            perm = db.query(Permission).filter(Permission.code == code).first()
            if not perm:
                perm = Permission(code=code, name=name, module=module)
                db.add(perm)
                db.flush()
            permission_map[code] = perm

        # 2. ROLES
        roles_data = [
            ("ADMIN", "Full system administrator with unrestricted access", False),
            ("MANAGER", "Operational manager with CRM and team oversight", False),
            ("EMPLOYEE", "Standard employee user with regular operational access", True),
        ]

        role_map = {}
        for name, desc, is_def in roles_data:
            role = db.query(Role).filter(Role.name == name).first()
            if not role:
                role = Role(name=name, description=desc, is_default=is_def)
                db.add(role)
                db.flush()
            role_map[name] = role

        # 3. ROLE-PERMISSION MAPPINGS
        # Admin gets ALL permissions
        for perm in permission_map.values():
            if not db.query(RolePermission).filter(
                RolePermission.role_id == role_map["ADMIN"].id,
                RolePermission.permission_id == perm.id
            ).first():
                db.add(RolePermission(role_id=role_map["ADMIN"].id, permission_id=perm.id))

        # Manager gets CRM + Audit + Read Users
        manager_perm_codes = [
            "AUTH_LOGIN", "AUTH_LOGOUT", "USER_READ", "AUDIT_LOG_READ",
            "CRM_CUSTOMER_CREATE", "CRM_CUSTOMER_READ", "CRM_CUSTOMER_UPDATE",
            "CRM_LEAD_CREATE", "CRM_LEAD_READ", "CRM_LEAD_UPDATE",
            "CRM_INTERACTION_CREATE", "CRM_INTERACTION_READ",
        ]
        for code in manager_perm_codes:
            if code in permission_map:
                perm = permission_map[code]
                if not db.query(RolePermission).filter(
                    RolePermission.role_id == role_map["MANAGER"].id,
                    RolePermission.permission_id == perm.id
                ).first():
                    db.add(RolePermission(role_id=role_map["MANAGER"].id, permission_id=perm.id))

        # Employee gets standard CRM view/create interaction and Auth
        employee_perm_codes = [
            "AUTH_LOGIN", "AUTH_LOGOUT",
            "CRM_CUSTOMER_READ", "CRM_LEAD_READ",
            "CRM_INTERACTION_CREATE", "CRM_INTERACTION_READ",
        ]
        for code in employee_perm_codes:
            if code in permission_map:
                perm = permission_map[code]
                if not db.query(RolePermission).filter(
                    RolePermission.role_id == role_map["EMPLOYEE"].id,
                    RolePermission.permission_id == perm.id
                ).first():
                    db.add(RolePermission(role_id=role_map["EMPLOYEE"].id, permission_id=perm.id))

        db.commit()

        # 4. INITIAL USERS
        users_seed = [
            {
                "full_name": settings.ADMIN_DEFAULT_NAME,
                "email": settings.ADMIN_DEFAULT_EMAIL,
                "username": settings.ADMIN_DEFAULT_USERNAME,
                "password": settings.ADMIN_DEFAULT_PASSWORD,
                "role": "ADMIN",
                "is_superuser": True,
            },
            {
                "full_name": "Marcus Reynolds",
                "email": "manager@smarterp.com",
                "username": "manager",
                "password": "ManagerPassword123!",
                "role": "MANAGER",
                "is_superuser": False,
            },
            {
                "full_name": "Sarah Connor",
                "email": "employee@smarterp.com",
                "username": "employee",
                "password": "EmployeePassword123!",
                "role": "EMPLOYEE",
                "is_superuser": False,
            },
        ]

        admin_user_ref = None
        for u_data in users_seed:
            user = db.query(User).filter(User.email == u_data["email"]).first()
            if not user:
                user = User(
                    full_name=u_data["full_name"],
                    email=u_data["email"],
                    username=u_data["username"],
                    hashed_password=get_password_hash(u_data["password"]),
                    is_active=True,
                    is_superuser=u_data["is_superuser"],
                )
                db.add(user)
                db.flush()
                # Assign role
                db.add(UserRole(user_id=user.id, role_id=role_map[u_data["role"]].id))
                db.commit()
                logger.info(f"Seeded user: {user.username} ({u_data['role']})")
            if u_data["role"] == "ADMIN":
                admin_user_ref = user

        # 5. SAMPLE CRM DATA (Member 3)
        if admin_user_ref and db.query(Customer).count() == 0:
            customers_seed = [
                {
                    "customer_code": "CUST-1001",
                    "name": "Acme Industrial Corp",
                    "company_name": "Acme Corporation Ltd",
                    "email": "contact@acmeindustries.com",
                    "phone": "+1 (555) 234-5678",
                    "website": "https://acmeindustries.example.com",
                    "industry": "Manufacturing",
                    "customer_type": "ENTERPRISE",
                    "status": "ACTIVE",
                    "city": "Chicago",
                    "state": "IL",
                    "country": "United States",
                    "annual_revenue": Decimal("2500000.00"),
                    "credit_limit": Decimal("500000.00"),
                    "notes": "Key manufacturing partner with recurring quarterly contracts.",
                },
                {
                    "customer_code": "CUST-1002",
                    "name": "Nova Cloud Systems",
                    "company_name": "Nova Cloud Technologies LLC",
                    "email": "billing@novacloud.io",
                    "phone": "+1 (555) 876-5432",
                    "website": "https://novacloud.example.com",
                    "industry": "Technology",
                    "customer_type": "CORPORATE",
                    "status": "ACTIVE",
                    "city": "San Francisco",
                    "state": "CA",
                    "country": "United States",
                    "annual_revenue": Decimal("1200000.00"),
                    "credit_limit": Decimal("250000.00"),
                    "notes": "SaaS infrastructure provider.",
                },
                {
                    "customer_code": "CUST-1003",
                    "name": "Stellar Logistics Ltd",
                    "company_name": "Stellar Freight & Cargo",
                    "email": "support@stellarlogistics.com",
                    "phone": "+1 (555) 432-1098",
                    "website": "https://stellarlogistics.example.com",
                    "industry": "Logistics",
                    "customer_type": "SMB",
                    "status": "PROSPECT",
                    "city": "Dallas",
                    "state": "TX",
                    "country": "United States",
                    "annual_revenue": Decimal("650000.00"),
                    "credit_limit": Decimal("100000.00"),
                    "notes": "Evaluation phase for enterprise supply chain integration.",
                },
            ]

            created_custs = []
            for c_info in customers_seed:
                cust = Customer(**c_info, assigned_to_id=admin_user_ref.id)
                db.add(cust)
                db.flush()
                created_custs.append(cust)

            # Sample Leads
            leads_seed = [
                {
                    "first_name": "David",
                    "last_name": "Miller",
                    "email": "david.miller@apexglobal.example.com",
                    "phone": "+1 (555) 345-6789",
                    "company": "Apex Global Solutions",
                    "title": "Chief Technology Officer",
                    "lead_source": "WEBSITE",
                    "lead_status": "QUALIFIED",
                    "lead_score": 85,
                    "estimated_value": Decimal("180000.00"),
                    "notes": "Requested demo of inventory and CRM modules.",
                },
                {
                    "first_name": "Elena",
                    "last_name": "Rostova",
                    "email": "e.rostova@vanguardtech.example.com",
                    "phone": "+1 (555) 987-6543",
                    "company": "Vanguard Robotics",
                    "title": "Head of Procurement",
                    "lead_source": "REFERRAL",
                    "lead_status": "PROPOSAL_SENT",
                    "lead_score": 92,
                    "estimated_value": Decimal("350000.00"),
                    "notes": "Proposal submitted for 200 seat enterprise rollout.",
                },
                {
                    "first_name": "James",
                    "last_name": "Wilson",
                    "email": "jwilson@greenenergy.example.com",
                    "phone": "+1 (555) 654-3210",
                    "company": "Green Energy Solutions",
                    "title": "Operations Director",
                    "lead_source": "CAMPAIGN",
                    "lead_status": "NEW",
                    "lead_score": 60,
                    "estimated_value": Decimal("95000.00"),
                    "notes": "Downloaded SmartERP whitepaper.",
                },
            ]

            created_leads = []
            for l_info in leads_seed:
                lead = Lead(**l_info, assigned_to_id=admin_user_ref.id)
                db.add(lead)
                db.flush()
                created_leads.append(lead)

            # Sample Customer & Lead Interactions / Timeline
            now = datetime.now(timezone.utc)
            interactions_seed = [
                {
                    "customer_id": created_custs[0].id,
                    "user_id": admin_user_ref.id,
                    "interaction_type": "MEETING",
                    "title": "Quarterly Business Review",
                    "notes": "Met with VP of Engineering to review SLA metrics and Q4 roadmap.",
                    "outcome": "COMPLETED",
                    "interaction_date": now - timedelta(days=2),
                    "next_follow_up": now + timedelta(days=14),
                },
                {
                    "customer_id": created_custs[1].id,
                    "user_id": admin_user_ref.id,
                    "interaction_type": "CALL",
                    "title": "Contract Renewal Discussion",
                    "notes": "Discussed 2-year enterprise agreement discount terms.",
                    "outcome": "FOLLOW_UP_REQUIRED",
                    "interaction_date": now - timedelta(days=1),
                    "next_follow_up": now + timedelta(days=3),
                },
                {
                    "lead_id": created_leads[0].id,
                    "user_id": admin_user_ref.id,
                    "interaction_type": "EMAIL",
                    "title": "Technical Architecture Whitepaper Sent",
                    "notes": "Sent API security specifications and compliance guide.",
                    "outcome": "COMPLETED",
                    "interaction_date": now - timedelta(hours=6),
                    "next_follow_up": now + timedelta(days=2),
                },
                {
                    "lead_id": created_leads[1].id,
                    "user_id": admin_user_ref.id,
                    "interaction_type": "MEETING",
                    "title": "Executive Presentation & Demo",
                    "notes": "Showcased SmartERP CRM pipeline and security RBAC architecture.",
                    "outcome": "COMPLETED",
                    "interaction_date": now - timedelta(hours=18),
                    "next_follow_up": now + timedelta(days=5),
                },
            ]

            for act in interactions_seed:
                db.add(CustomerHistory(**act))

            db.commit()
            logger.info("Seeded initial CRM customers, leads, and customer interaction history.")

    except Exception as e:
        db.rollback()
        logger.error(f"Error seeding database: {e}")
        raise e
    finally:
        if close_db:
            db.close()


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    seed_database()
    print("Database seeding completed successfully!")
