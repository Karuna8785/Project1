import logging
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base
from app.core.config import settings

logger = logging.getLogger("smarterp.database")

Base = declarative_base()


def get_engine():
    """Create database engine with quick connection test and automatic fallback."""
    database_url = settings.DATABASE_URL
    try:
        if database_url.startswith("sqlite"):
            engine = create_engine(
                database_url,
                connect_args={"check_same_thread": False}
            )
            return engine
        else:
            # PostgreSQL URL format
            pg_url = database_url
            if pg_url.startswith("postgresql://") and not pg_url.startswith("postgresql+"):
                pg_url = pg_url.replace("postgresql://", "postgresql+psycopg://", 1)
            
            engine = create_engine(
                pg_url,
                pool_pre_ping=True,
                pool_size=10,
                max_overflow=20,
                connect_args={"connect_timeout": 1}
            )
            # Fast test connection
            with engine.connect() as conn:
                pass
            logger.info("Connected successfully to PostgreSQL database.")
            return engine
    except Exception as e:
        logger.warning(f"PostgreSQL server not detected locally ({e}).")
        if settings.DB_FALLBACK_SQLITE:
            fallback_url = "sqlite:///./smarterp.db"
            logger.info(f"Using local database: {fallback_url}")
            engine = create_engine(
                fallback_url,
                connect_args={"check_same_thread": False}
            )
            return engine
        raise e


engine = get_engine()
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


def get_db():
    """FastAPI dependency for database session."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
