from datetime import datetime, timezone
from typing import List, Optional, Dict, Any
from decimal import Decimal
from sqlalchemy.orm import Session
from sqlalchemy import func, or_, desc
from fastapi import HTTPException, status
from app.models.customer import Customer
from app.models.lead import Lead
from app.models.customer_history import CustomerHistory
from app.schemas.customer import CustomerCreate, CustomerUpdate, CustomerStats
from app.schemas.lead import LeadCreate, LeadUpdate, LeadConvertRequest, LeadPipelineStats
from app.schemas.customer_history import CustomerHistoryCreate, CustomerHistoryUpdate
from app.services.audit_service import log_security_event


def generate_customer_code(db: Session) -> str:
    """Generate sequential customer code like CUST-1001."""
    last_customer = db.query(Customer).order_by(Customer.id.desc()).first()
    if not last_customer:
        return "CUST-1001"
    try:
        current_num = int(last_customer.customer_code.split("-")[-1])
        return f"CUST-{current_num + 1}"
    except Exception:
        return f"CUST-{last_customer.id + 1000}"


# ============================================================================
# CUSTOMER OPERATIONS
# ============================================================================

def get_customer_by_id(db: Session, customer_id: int) -> Optional[Customer]:
    return db.query(Customer).filter(Customer.id == customer_id).first()


def get_customer_by_email(db: Session, email: str) -> Optional[Customer]:
    return db.query(Customer).filter(Customer.email.ilike(email.strip())).first()


def get_customers(
    db: Session,
    skip: int = 0,
    limit: int = 50,
    search: Optional[str] = None,
    status: Optional[str] = None,
    industry: Optional[str] = None,
    assigned_to_id: Optional[int] = None,
) -> List[Customer]:
    query = db.query(Customer)
    if search:
        search_fmt = f"%{search.strip()}%"
        query = query.filter(
            or_(
                Customer.name.ilike(search_fmt),
                Customer.company_name.ilike(search_fmt),
                Customer.email.ilike(search_fmt),
                Customer.customer_code.ilike(search_fmt),
                Customer.phone.ilike(search_fmt),
            )
        )
    if status:
        query = query.filter(Customer.status == status.upper())
    if industry:
        query = query.filter(Customer.industry.ilike(f"%{industry.strip()}%"))
    if assigned_to_id:
        query = query.filter(Customer.assigned_to_id == assigned_to_id)
    
    return query.order_by(Customer.id.desc()).offset(skip).limit(limit).all()


def create_customer(db: Session, customer_in: CustomerCreate, current_user_id: int) -> Customer:
    if get_customer_by_email(db, customer_in.email):
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="A customer with this email address already exists.",
        )

    code = customer_in.customer_code or generate_customer_code(db)
    
    db_customer = Customer(
        customer_code=code,
        name=customer_in.name,
        company_name=customer_in.company_name,
        email=customer_in.email.lower().strip(),
        phone=customer_in.phone,
        website=customer_in.website,
        industry=customer_in.industry,
        customer_type=customer_in.customer_type,
        status=customer_in.status,
        address_line1=customer_in.address_line1,
        address_line2=customer_in.address_line2,
        city=customer_in.city,
        state=customer_in.state,
        postal_code=customer_in.postal_code,
        country=customer_in.country,
        annual_revenue=customer_in.annual_revenue,
        credit_limit=customer_in.credit_limit,
        notes=customer_in.notes,
        assigned_to_id=customer_in.assigned_to_id or current_user_id,
    )
    db.add(db_customer)
    db.commit()
    db.refresh(db_customer)

    # Automatically add an initial history record
    initial_log = CustomerHistory(
        customer_id=db_customer.id,
        user_id=current_user_id,
        interaction_type="NOTE",
        title="Customer Record Created",
        notes=f"Customer account {db_customer.customer_code} was created.",
        outcome="COMPLETED",
        interaction_date=datetime.now(timezone.utc),
    )
    db.add(initial_log)
    db.commit()

    return db_customer


def update_customer(db: Session, customer_id: int, customer_in: CustomerUpdate, current_user_id: int) -> Customer:
    db_customer = get_customer_by_id(db, customer_id)
    if not db_customer:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Customer not found")

    update_data = customer_in.model_dump(exclude_unset=True)
    if "email" in update_data and update_data["email"]:
        existing = get_customer_by_email(db, update_data["email"])
        if existing and existing.id != customer_id:
            raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Email already used by another customer")

    for field, value in update_data.items():
        setattr(db_customer, field, value)

    db.commit()
    db.refresh(db_customer)
    return db_customer


def delete_customer(db: Session, customer_id: int) -> bool:
    db_customer = get_customer_by_id(db, customer_id)
    if not db_customer:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Customer not found")
    db.delete(db_customer)
    db.commit()
    return True


def get_customer_stats(db: Session) -> CustomerStats:
    total = db.query(func.count(Customer.id)).scalar() or 0
    active = db.query(func.count(Customer.id)).filter(Customer.status == "ACTIVE").scalar() or 0
    prospects = db.query(func.count(Customer.id)).filter(Customer.status == "PROSPECT").scalar() or 0
    rev_sum = db.query(func.sum(Customer.annual_revenue)).scalar() or Decimal("0.00")

    return CustomerStats(
        total_customers=total,
        active_customers=active,
        prospects=prospects,
        total_estimated_revenue=Decimal(str(rev_sum)),
    )


# ============================================================================
# LEAD OPERATIONS
# ============================================================================

def get_lead_by_id(db: Session, lead_id: int) -> Optional[Lead]:
    return db.query(Lead).filter(Lead.id == lead_id).first()


def get_lead_by_email(db: Session, email: str) -> Optional[Lead]:
    return db.query(Lead).filter(Lead.email.ilike(email.strip())).first()


def get_leads(
    db: Session,
    skip: int = 0,
    limit: int = 50,
    search: Optional[str] = None,
    status: Optional[str] = None,
    lead_source: Optional[str] = None,
    assigned_to_id: Optional[int] = None,
) -> List[Lead]:
    query = db.query(Lead)
    if search:
        search_fmt = f"%{search.strip()}%"
        query = query.filter(
            or_(
                Lead.first_name.ilike(search_fmt),
                Lead.last_name.ilike(search_fmt),
                Lead.company.ilike(search_fmt),
                Lead.email.ilike(search_fmt),
                Lead.phone.ilike(search_fmt),
            )
        )
    if status:
        query = query.filter(Lead.lead_status == status.upper())
    if lead_source:
        query = query.filter(Lead.lead_source == lead_source.upper())
    if assigned_to_id:
        query = query.filter(Lead.assigned_to_id == assigned_to_id)

    return query.order_by(Lead.id.desc()).offset(skip).limit(limit).all()


def create_lead(db: Session, lead_in: LeadCreate, current_user_id: int) -> Lead:
    if get_lead_by_email(db, lead_in.email):
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="A lead with this email address already exists.",
        )

    db_lead = Lead(
        first_name=lead_in.first_name,
        last_name=lead_in.last_name,
        email=lead_in.email.lower().strip(),
        phone=lead_in.phone,
        company=lead_in.company,
        title=lead_in.title,
        lead_source=lead_in.lead_source,
        lead_status=lead_in.lead_status,
        lead_score=lead_in.lead_score,
        estimated_value=lead_in.estimated_value,
        notes=lead_in.notes,
        assigned_to_id=lead_in.assigned_to_id or current_user_id,
    )
    db.add(db_lead)
    db.commit()
    db.refresh(db_lead)

    # Initial history log
    initial_log = CustomerHistory(
        lead_id=db_lead.id,
        user_id=current_user_id,
        interaction_type="NOTE",
        title="Lead Created",
        notes=f"Lead {db_lead.full_name} ({db_lead.company or 'Individual'}) added to pipeline.",
        outcome="COMPLETED",
        interaction_date=datetime.now(timezone.utc),
    )
    db.add(initial_log)
    db.commit()

    return db_lead


def update_lead(db: Session, lead_id: int, lead_in: LeadUpdate, current_user_id: int) -> Lead:
    db_lead = get_lead_by_id(db, lead_id)
    if not db_lead:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Lead not found")

    old_status = db_lead.lead_status
    update_data = lead_in.model_dump(exclude_unset=True)
    if "email" in update_data and update_data["email"]:
        existing = get_lead_by_email(db, update_data["email"])
        if existing and existing.id != lead_id:
            raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Email already used by another lead")

    for field, value in update_data.items():
        setattr(db_lead, field, value)

    # If status changed, log interaction history
    if "lead_status" in update_data and update_data["lead_status"] != old_status:
        hist = CustomerHistory(
            lead_id=db_lead.id,
            user_id=current_user_id,
            interaction_type="STATUS_CHANGE",
            title=f"Status changed from {old_status} to {db_lead.lead_status}",
            notes=f"Updated lead pipeline stage.",
            outcome="COMPLETED",
            interaction_date=datetime.now(timezone.utc),
        )
        db.add(hist)

    db.commit()
    db.refresh(db_lead)
    return db_lead


def delete_lead(db: Session, lead_id: int) -> bool:
    db_lead = get_lead_by_id(db, lead_id)
    if not db_lead:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Lead not found")
    db.delete(db_lead)
    db.commit()
    return True


def convert_lead_to_customer(
    db: Session,
    lead_id: int,
    convert_in: LeadConvertRequest,
    current_user_id: int,
) -> Customer:
    """Converts a qualified sales Lead into an active ERP Customer."""
    db_lead = get_lead_by_id(db, lead_id)
    if not db_lead:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Lead not found")

    if db_lead.converted_customer_id:
        existing_cust = get_customer_by_id(db, db_lead.converted_customer_id)
        if existing_cust:
            return existing_cust

    # Check if customer already exists with this email
    existing_customer = get_customer_by_email(db, db_lead.email)
    if existing_customer:
        db_lead.converted_customer_id = existing_customer.id
        db_lead.converted_at = datetime.now(timezone.utc)
        db_lead.lead_status = "WON"
        db.commit()
        return existing_customer

    # Create new customer from lead
    cust_code = generate_customer_code(db)
    cust_name = convert_in.customer_name or db_lead.full_name

    new_customer = Customer(
        customer_code=cust_code,
        name=cust_name,
        company_name=db_lead.company or cust_name,
        email=db_lead.email,
        phone=db_lead.phone,
        industry=convert_in.industry or "Technology",
        customer_type=convert_in.customer_type or "CORPORATE",
        status="ACTIVE",
        annual_revenue=db_lead.estimated_value,
        assigned_to_id=db_lead.assigned_to_id or current_user_id,
        notes=f"Converted from Lead #{db_lead.id}: {db_lead.notes or ''}",
    )
    db.add(new_customer)
    db.flush()

    # Link lead
    db_lead.converted_customer_id = new_customer.id
    db_lead.converted_at = datetime.now(timezone.utc)
    db_lead.lead_status = "WON"

    # Transfer interaction history
    history_record = CustomerHistory(
        customer_id=new_customer.id,
        lead_id=db_lead.id,
        user_id=current_user_id,
        interaction_type="DEAL_UPDATE",
        title="Lead Converted to Customer",
        notes=convert_in.create_interaction_note or f"Lead {db_lead.full_name} successfully converted.",
        outcome="COMPLETED",
        interaction_date=datetime.now(timezone.utc),
    )
    db.add(history_record)

    db.commit()
    db.refresh(new_customer)
    return new_customer


def get_lead_pipeline_stats(db: Session) -> LeadPipelineStats:
    total = db.query(func.count(Lead.id)).scalar() or 0
    new_l = db.query(func.count(Lead.id)).filter(Lead.lead_status == "NEW").scalar() or 0
    qual_l = db.query(func.count(Lead.id)).filter(Lead.lead_status == "QUALIFIED").scalar() or 0
    won_l = db.query(func.count(Lead.id)).filter(Lead.lead_status == "WON").scalar() or 0
    val_sum = db.query(func.sum(Lead.estimated_value)).scalar() or Decimal("0.00")

    conv_rate = (won_l / total * 100.0) if total > 0 else 0.0

    return LeadPipelineStats(
        total_leads=total,
        new_leads=new_l,
        qualified_leads=qual_l,
        won_leads=won_l,
        conversion_rate=round(conv_rate, 2),
        pipeline_value=Decimal(str(val_sum)),
    )


# ============================================================================
# CUSTOMER HISTORY & INTERACTION LOGS
# ============================================================================

def create_interaction(
    db: Session,
    history_in: CustomerHistoryCreate,
    current_user_id: int,
) -> CustomerHistory:
    if not history_in.customer_id and not history_in.lead_id:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Either customer_id or lead_id must be provided.",
        )

    db_hist = CustomerHistory(
        customer_id=history_in.customer_id,
        lead_id=history_in.lead_id,
        user_id=current_user_id,
        interaction_type=history_in.interaction_type.upper(),
        title=history_in.title,
        notes=history_in.notes,
        outcome=history_in.outcome or "COMPLETED",
        interaction_date=history_in.interaction_date or datetime.now(timezone.utc),
        next_follow_up=history_in.next_follow_up,
    )
    db.add(db_hist)
    db.commit()
    db.refresh(db_hist)
    return db_hist


def get_customer_timeline(db: Session, customer_id: int) -> List[CustomerHistory]:
    return (
        db.query(CustomerHistory)
        .filter(CustomerHistory.customer_id == customer_id)
        .order_by(CustomerHistory.interaction_date.desc())
        .all()
    )


def get_lead_timeline(db: Session, lead_id: int) -> List[CustomerHistory]:
    return (
        db.query(CustomerHistory)
        .filter(CustomerHistory.lead_id == lead_id)
        .order_by(CustomerHistory.interaction_date.desc())
        .all()
    )


def get_recent_interactions(db: Session, limit: int = 20) -> List[CustomerHistory]:
    return (
        db.query(CustomerHistory)
        .order_by(CustomerHistory.created_at.desc())
        .limit(limit)
        .all()
    )


def get_upcoming_followups(db: Session, limit: int = 20) -> List[CustomerHistory]:
    now = datetime.now(timezone.utc)
    return (
        db.query(CustomerHistory)
        .filter(CustomerHistory.next_follow_up >= now)
        .order_by(CustomerHistory.next_follow_up.asc())
        .limit(limit)
        .all()
    )


def get_crm_overview_stats(db: Session) -> Dict[str, Any]:
    cust_stats = get_customer_stats(db)
    lead_stats = get_lead_pipeline_stats(db)
    recent_interactions = get_recent_interactions(db, limit=5)
    upcoming_followups = get_upcoming_followups(db, limit=5)

    return {
        "customers": cust_stats.model_dump(),
        "leads": lead_stats.model_dump(),
        "recent_activities_count": len(recent_interactions),
        "upcoming_followups_count": len(upcoming_followups),
    }
