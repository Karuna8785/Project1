from typing import Optional, Dict, Any
from sqlalchemy.orm import Session
from fastapi import HTTPException, status
from app.models.user import User
from app.schemas.auth import RegisterRequest, LoginRequest, TokenResponse, UserSummary
from app.services.user_service import get_user_by_email, get_user_by_username, create_user
from app.services.audit_service import log_security_event
from app.schemas.user import UserCreate
from app.core.security import verify_password, create_access_token, get_password_hash
from app.core.config import settings


def authenticate_user(
    db: Session,
    login_data: LoginRequest,
    ip_address: Optional[str] = None,
    user_agent: Optional[str] = None,
) -> TokenResponse:
    identifier = login_data.username_or_email.strip()
    user = get_user_by_email(db, identifier) or get_user_by_username(db, identifier)

    if not user:
        log_security_event(
            db=db,
            action="LOGIN_FAILED_USER_NOT_FOUND",
            user_email=identifier,
            entity_type="AUTH",
            ip_address=ip_address,
            user_agent=user_agent,
            details={"identifier": identifier, "reason": "User not found"},
        )
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid email/username or password",
            headers={"WWW-Authenticate": "Bearer"},
        )

    if not verify_password(login_data.password, user.hashed_password):
        log_security_event(
            db=db,
            action="LOGIN_FAILED_WRONG_PASSWORD",
            user_id=user.id,
            user_email=user.email,
            entity_type="AUTH",
            ip_address=ip_address,
            user_agent=user_agent,
            details={"username": user.username, "reason": "Incorrect password"},
        )
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid email/username or password",
            headers={"WWW-Authenticate": "Bearer"},
        )

    if not user.is_active:
        log_security_event(
            db=db,
            action="LOGIN_BLOCKED_INACTIVE_USER",
            user_id=user.id,
            user_email=user.email,
            entity_type="AUTH",
            ip_address=ip_address,
            user_agent=user_agent,
            details={"username": user.username, "reason": "Account is deactivated"},
        )
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Account is inactive. Please contact your system administrator.",
        )

    # Issue JWT token
    extra_claims: Dict[str, Any] = {
        "email": user.email,
        "username": user.username,
        "role": user.primary_role,
        "roles": user.role_names,
        "permissions": user.permissions,
    }
    access_token = create_access_token(
        subject=str(user.id),
        extra_claims=extra_claims,
    )

    log_security_event(
        db=db,
        action="LOGIN_SUCCESS",
        user_id=user.id,
        user_email=user.email,
        entity_type="AUTH",
        ip_address=ip_address,
        user_agent=user_agent,
        details={"username": user.username, "primary_role": user.primary_role},
    )

    user_summary = UserSummary(
        id=user.id,
        full_name=user.full_name,
        email=user.email,
        username=user.username,
        role=user.primary_role,
        roles=user.role_names,
        permissions=user.permissions,
        is_active=user.is_active,
    )

    return TokenResponse(
        access_token=access_token,
        token_type="bearer",
        expires_in=settings.ACCESS_TOKEN_EXPIRE_MINUTES * 60,
        user=user_summary,
    )


def register_user(
    db: Session,
    reg_data: RegisterRequest,
    ip_address: Optional[str] = None,
    user_agent: Optional[str] = None,
) -> UserSummary:
    # Check duplicate email
    if get_user_by_email(db, reg_data.email):
        log_security_event(
            db=db,
            action="REGISTRATION_REJECTED_DUPLICATE_EMAIL",
            user_email=reg_data.email,
            entity_type="AUTH",
            ip_address=ip_address,
            user_agent=user_agent,
            details={"email": reg_data.email, "reason": "Email already exists"},
        )
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="A user with this email address already exists.",
        )

    # Check duplicate username
    if get_user_by_username(db, reg_data.username):
        log_security_event(
            db=db,
            action="REGISTRATION_REJECTED_DUPLICATE_USERNAME",
            user_email=reg_data.email,
            entity_type="AUTH",
            ip_address=ip_address,
            user_agent=user_agent,
            details={"username": reg_data.username, "reason": "Username already taken"},
        )
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="A user with this username already exists.",
        )

    # Create user with EMPLOYEE role by default
    user_in = UserCreate(
        full_name=reg_data.full_name,
        email=reg_data.email,
        username=reg_data.username,
        password=reg_data.password,
        role_names=["EMPLOYEE"],
    )
    user = create_user(db, user_in)

    log_security_event(
        db=db,
        action="REGISTRATION_SUCCESS",
        user_id=user.id,
        user_email=user.email,
        entity_type="AUTH",
        entity_id=str(user.id),
        ip_address=ip_address,
        user_agent=user_agent,
        details={"username": user.username, "role": "EMPLOYEE"},
    )

    return UserSummary(
        id=user.id,
        full_name=user.full_name,
        email=user.email,
        username=user.username,
        role=user.primary_role,
        roles=user.role_names,
        permissions=user.permissions,
        is_active=user.is_active,
    )
