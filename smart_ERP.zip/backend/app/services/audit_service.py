import logging
import json
from typing import Optional, Any, Dict
from sqlalchemy.orm import Session
from app.models.audit_log import AuditLog

logger = logging.getLogger("smarterp.audit")


def log_security_event(
    db: Session,
    action: str,
    user_id: Optional[int] = None,
    user_email: Optional[str] = None,
    entity_type: Optional[str] = None,
    entity_id: Optional[str] = None,
    ip_address: Optional[str] = None,
    user_agent: Optional[str] = None,
    details: Optional[Any] = None,
) -> AuditLog:
    """Create a persistent security audit log record."""
    try:
        details_str = None
        if details is not None:
            if isinstance(details, (dict, list)):
                # Ensure no passwords are logged
                sanitized = details.copy() if isinstance(details, dict) else list(details)
                if isinstance(sanitized, dict):
                    for secret_key in ["password", "hashed_password", "token", "access_token", "secret"]:
                        if secret_key in sanitized:
                            sanitized[secret_key] = "[REDACTED]"
                details_str = json.dumps(sanitized)
            else:
                details_str = str(details)

        audit_entry = AuditLog(
            user_id=user_id,
            user_email=user_email,
            action=action,
            entity_type=entity_type,
            entity_id=str(entity_id) if entity_id is not None else None,
            ip_address=ip_address,
            user_agent=user_agent[:255] if user_agent else None,
            details=details_str,
        )
        db.add(audit_entry)
        db.commit()
        db.refresh(audit_entry)
        logger.info(f"AUDIT LOG: action={action} user={user_email or user_id} ip={ip_address}")
        return audit_entry
    except Exception as e:
        db.rollback()
        logger.error(f"Failed to write audit log: {e}")
        return None


def get_audit_logs(
    db: Session,
    skip: int = 0,
    limit: int = 100,
    user_id: Optional[int] = None,
    action: Optional[str] = None,
    entity_type: Optional[str] = None,
):
    query = db.query(AuditLog)
    if user_id:
        query = query.filter(AuditLog.user_id == user_id)
    if action:
        query = query.filter(AuditLog.action == action)
    if entity_type:
        query = query.filter(AuditLog.entity_type == entity_type)
    return query.order_by(AuditLog.created_at.desc()).offset(skip).limit(limit).all()
