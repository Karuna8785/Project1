from typing import List, Optional
from sqlalchemy.orm import Session
from app.models.user import User
from app.models.role import Role, UserRole
from app.schemas.user import UserCreate, UserUpdate
from app.core.security import get_password_hash


def get_user_by_id(db: Session, user_id: int) -> Optional[User]:
    return db.query(User).filter(User.id == user_id).first()


def get_user_by_email(db: Session, email: str) -> Optional[User]:
    return db.query(User).filter(User.email.ilike(email.strip())).first()


def get_user_by_username(db: Session, username: str) -> Optional[User]:
    return db.query(User).filter(User.username.ilike(username.strip())).first()


def get_users(db: Session, skip: int = 0, limit: int = 100) -> List[User]:
    return db.query(User).order_by(User.id.asc()).offset(skip).limit(limit).all()


def create_user(db: Session, user_in: UserCreate) -> User:
    hashed_password = get_password_hash(user_in.password)
    db_user = User(
        full_name=user_in.full_name,
        email=user_in.email.lower().strip(),
        username=user_in.username.strip(),
        hashed_password=hashed_password,
        is_active=user_in.is_active,
        is_superuser=user_in.is_superuser,
    )
    db.add(db_user)
    db.flush()

    # Assign default or requested roles
    role_names = user_in.role_names or ["EMPLOYEE"]
    for r_name in role_names:
        role = db.query(Role).filter(Role.name == r_name.upper()).first()
        if role:
            user_role = UserRole(user_id=db_user.id, role_id=role.id)
            db.add(user_role)

    db.commit()
    db.refresh(db_user)
    return db_user


def update_user(db: Session, db_user: User, user_in: UserUpdate) -> User:
    if user_in.full_name is not None:
        db_user.full_name = user_in.full_name
    if user_in.email is not None:
        db_user.email = user_in.email.lower().strip()
    if user_in.is_active is not None:
        db_user.is_active = user_in.is_active
    if user_in.password:
        db_user.hashed_password = get_password_hash(user_in.password)
    
    if user_in.role_names is not None:
        # Clear existing
        db.query(UserRole).filter(UserRole.user_id == db_user.id).delete()
        for r_name in user_in.role_names:
            role = db.query(Role).filter(Role.name == r_name.upper()).first()
            if role:
                db.add(UserRole(user_id=db_user.id, role_id=role.id))

    db.commit()
    db.refresh(db_user)
    return db_user


def assign_user_roles(db: Session, user_id: int, role_ids: List[int]) -> User:
    db_user = get_user_by_id(db, user_id)
    if not db_user:
        return None
    db.query(UserRole).filter(UserRole.user_id == user_id).delete()
    for r_id in role_ids:
        role = db.query(Role).filter(Role.id == r_id).first()
        if role:
            db.add(UserRole(user_id=user_id, role_id=role.id))
    db.commit()
    db.refresh(db_user)
    return db_user
