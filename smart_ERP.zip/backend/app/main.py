import logging
from contextlib import asynccontextmanager
from fastapi import FastAPI, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from app.core.config import settings
from app.api.routes import api_router
from app.middleware.logging_middleware import RequestLoggingMiddleware
from app.database.init_db import init_db

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger("smarterp.main")


@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("Initializing SmartERP Application...")
    try:
        init_db()
        logger.info("SmartERP Database initialized and seeded successfully.")
    except Exception as e:
        logger.error(f"Error during startup DB initialization: {e}")
    yield
    logger.info("Shutting down SmartERP Application...")


app = FastAPI(
    title=settings.PROJECT_NAME,
    version=settings.VERSION,
    description="""
# SmartERP — Enterprise Resource Planning Backend API

### Architecture:
- **Module 1**: Authentication & Security (JWT, RBAC, Passlib/Bcrypt, Security Audit Logging)
- **Module 3 (Member 3)**: CRM (Customers, Sales Leads, Customer Interaction History & Follow-ups)
- **Upcoming Modules 2, 4, 5, 6, 7**: HR, Inventory, Sales, Procurement, Finance, Reports (Structured endpoints ready for modular extension)
    """,
    openapi_url=f"{settings.API_V1_STR}/openapi.json",
    docs_url="/docs",
    redoc_url="/redoc",
    lifespan=lifespan,
)

# CORS Middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS if isinstance(settings.CORS_ORIGINS, list) else ["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Request Logging Middleware
app.add_middleware(RequestLoggingMiddleware)

# Mount API Routers
app.include_router(api_router, prefix=settings.API_V1_STR)


@app.get("/", tags=["Health & Status"])
def root():
    return {
        "app": settings.PROJECT_NAME,
        "version": settings.VERSION,
        "status": "online",
        "docs_url": "/docs",
        "redoc_url": "/redoc",
        "api_v1": settings.API_V1_STR,
    }


@app.get("/health", tags=["Health & Status"])
def health_check():
    return {
        "status": "healthy",
        "timestamp": "ok",
        "environment": "local",
    }
