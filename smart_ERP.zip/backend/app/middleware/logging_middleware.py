import time
import logging
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import Response

logger = logging.getLogger("smarterp.http")


class RequestLoggingMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        start_time = time.time()
        response: Response = await call_next(request)
        process_time = (time.time() - start_time) * 1000
        
        # Don't log health or docs excessively
        if not request.url.path.startswith("/docs") and not request.url.path.startswith("/openapi.json"):
            logger.info(
                f"{request.method} {request.url.path} -> Status {response.status_code} ({process_time:.2f}ms)"
            )
        
        response.headers["X-Process-Time-Ms"] = f"{process_time:.2f}"
        return response
