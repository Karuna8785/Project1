from fastapi import APIRouter, Depends
from app.api.deps import get_current_user
from app.models.user import User

router = APIRouter(prefix="/procurement", tags=["Procurement & Finance (Member 6 — Upcoming)"])


@router.get("/status", summary="Procurement Module Status")
def get_procurement_status(current_user: User = Depends(get_current_user)):
    return {
        "module": "Procurement & Purchasing",
        "status": "Planned for Phase 2",
        "description": "Suppliers, Purchase Orders, and Receiving will be connected here.",
        "version": "0.1.0-alpha",
    }
