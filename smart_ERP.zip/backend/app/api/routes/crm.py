from typing import List, Optional, Dict, Any
from fastapi import APIRouter, Depends, Query, status, HTTPException
from sqlalchemy.orm import Session
from app.database.session import get_db
from app.models.user import User
from app.models.customer import Customer
from app.models.lead import Lead
from app.schemas.customer import CustomerCreate, CustomerUpdate, CustomerOut, CustomerDetailOut, CustomerStats
from app.schemas.lead import LeadCreate, LeadUpdate, LeadConvertRequest, LeadOut, LeadDetailOut, LeadPipelineStats
from app.schemas.customer_history import CustomerHistoryCreate, CustomerHistoryOut
from app.services import crm_service
from app.services.audit_service import log_security_event
from app.api.deps import get_current_user, require_role

router = APIRouter(prefix="/crm", tags=["Member 3 — CRM (Customers, Leads, History)"])


# ============================================================================
# OVERVIEW & STATS
# ============================================================================

@router.get("/overview", response_model=Dict[str, Any], summary="Get CRM Dashboard Overview Stats")
def get_crm_overview(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    return crm_service.get_crm_overview_stats(db)


@router.get("/stats/customers", response_model=CustomerStats, summary="Get customer statistics")
def get_customers_stats(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    return crm_service.get_customer_stats(db)


@router.get("/stats/leads", response_model=LeadPipelineStats, summary="Get lead pipeline statistics")
def get_leads_pipeline_stats(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    return crm_service.get_lead_pipeline_stats(db)


# ============================================================================
# CUSTOMERS ENDPOINTS
# ============================================================================

@router.get("/customers", response_model=List[CustomerOut], summary="List customers with filters")
def list_customers(
    skip: int = 0,
    limit: int = 50,
    search: Optional[str] = Query(None, description="Search by name, company, email, code"),
    status: Optional[str] = Query(None, description="Filter by status (ACTIVE, INACTIVE, PROSPECT, BLOCKED)"),
    industry: Optional[str] = Query(None, description="Filter by industry"),
    assigned_to_id: Optional[int] = Query(None, description="Filter by account owner user ID"),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    customers = crm_service.get_customers(
        db=db,
        skip=skip,
        limit=limit,
        search=search,
        status=status,
        industry=industry,
        assigned_to_id=assigned_to_id,
    )
    return [CustomerOut.from_orm_custom(c) for c in customers]


@router.post("/customers", response_model=CustomerOut, status_code=status.HTTP_201_CREATED, summary="Create a new customer")
def create_customer(
    customer_in: CustomerCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    new_customer = crm_service.create_customer(db, customer_in, current_user.id)
    log_security_event(
        db=db,
        action="CRM_CUSTOMER_CREATED",
        user_id=current_user.id,
        user_email=current_user.email,
        entity_type="CUSTOMER",
        entity_id=str(new_customer.id),
        details={"name": new_customer.name, "customer_code": new_customer.customer_code},
    )
    return CustomerOut.from_orm_custom(new_customer)


@router.get("/customers/{customer_id}", response_model=CustomerDetailOut, summary="Get customer by ID with interactions")
def get_customer(
    customer_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    customer = crm_service.get_customer_by_id(db, customer_id)
    if not customer:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Customer not found")
    
    interactions_out = [CustomerHistoryOut.from_orm_custom(h) for h in customer.interactions]
    base = CustomerOut.from_orm_custom(customer)
    return CustomerDetailOut(
        **base.model_dump(),
        interactions=interactions_out,
    )


@router.put("/customers/{customer_id}", response_model=CustomerOut, summary="Update an existing customer")
def update_customer(
    customer_id: int,
    customer_in: CustomerUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    updated = crm_service.update_customer(db, customer_id, customer_in, current_user.id)
    return CustomerOut.from_orm_custom(updated)


@router.delete("/customers/{customer_id}", summary="Delete customer (Admin/Manager only)")
def delete_customer(
    customer_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role(["ADMIN", "MANAGER"])),
):
    crm_service.delete_customer(db, customer_id)
    log_security_event(
        db=db,
        action="CRM_CUSTOMER_DELETED",
        user_id=current_user.id,
        user_email=current_user.email,
        entity_type="CUSTOMER",
        entity_id=str(customer_id),
    )
    return {"message": f"Customer #{customer_id} deleted successfully"}


@router.get("/customers/{customer_id}/timeline", response_model=List[CustomerHistoryOut], summary="Get customer interaction timeline")
def get_customer_timeline(
    customer_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    histories = crm_service.get_customer_timeline(db, customer_id)
    return [CustomerHistoryOut.from_orm_custom(h) for h in histories]


# ============================================================================
# LEADS ENDPOINTS
# ============================================================================

@router.get("/leads", response_model=List[LeadOut], summary="List leads with filters")
def list_leads(
    skip: int = 0,
    limit: int = 50,
    search: Optional[str] = Query(None, description="Search by name, company, email"),
    status: Optional[str] = Query(None, description="Filter by status (NEW, CONTACTED, QUALIFIED, PROPOSAL_SENT, NEGOTIATION, WON, LOST)"),
    lead_source: Optional[str] = Query(None, description="Filter by lead source"),
    assigned_to_id: Optional[int] = Query(None, description="Filter by assignee user ID"),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    leads = crm_service.get_leads(
        db=db,
        skip=skip,
        limit=limit,
        search=search,
        status=status,
        lead_source=lead_source,
        assigned_to_id=assigned_to_id,
    )
    return [LeadOut.from_orm_custom(l) for l in leads]


@router.post("/leads", response_model=LeadOut, status_code=status.HTTP_201_CREATED, summary="Create a new sales lead")
def create_lead(
    lead_in: LeadCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    new_lead = crm_service.create_lead(db, lead_in, current_user.id)
    log_security_event(
        db=db,
        action="CRM_LEAD_CREATED",
        user_id=current_user.id,
        user_email=current_user.email,
        entity_type="LEAD",
        entity_id=str(new_lead.id),
        details={"name": new_lead.full_name, "company": new_lead.company},
    )
    return LeadOut.from_orm_custom(new_lead)


@router.get("/leads/{lead_id}", response_model=LeadDetailOut, summary="Get lead by ID with interactions")
def get_lead(
    lead_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    lead = crm_service.get_lead_by_id(db, lead_id)
    if not lead:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Lead not found")
    
    interactions_out = [CustomerHistoryOut.from_orm_custom(h) for h in lead.interactions]
    base = LeadOut.from_orm_custom(lead)
    return LeadDetailOut(
        **base.model_dump(),
        interactions=interactions_out,
    )


@router.put("/leads/{lead_id}", response_model=LeadOut, summary="Update an existing lead")
def update_lead(
    lead_id: int,
    lead_in: LeadUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    updated = crm_service.update_lead(db, lead_id, lead_in, current_user.id)
    return LeadOut.from_orm_custom(updated)


@router.delete("/leads/{lead_id}", summary="Delete lead")
def delete_lead(
    lead_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role(["ADMIN", "MANAGER"])),
):
    crm_service.delete_lead(db, lead_id)
    return {"message": f"Lead #{lead_id} deleted successfully"}


@router.post("/leads/{lead_id}/convert", response_model=CustomerOut, summary="Convert a qualified Lead into a Customer")
def convert_lead(
    lead_id: int,
    convert_in: LeadConvertRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    customer = crm_service.convert_lead_to_customer(db, lead_id, convert_in, current_user.id)
    log_security_event(
        db=db,
        action="CRM_LEAD_CONVERTED_TO_CUSTOMER",
        user_id=current_user.id,
        user_email=current_user.email,
        entity_type="LEAD",
        entity_id=str(lead_id),
        details={"customer_id": customer.id, "customer_code": customer.customer_code},
    )
    return CustomerOut.from_orm_custom(customer)


@router.get("/leads/{lead_id}/timeline", response_model=List[CustomerHistoryOut], summary="Get lead interaction timeline")
def get_lead_timeline(
    lead_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    histories = crm_service.get_lead_timeline(db, lead_id)
    return [CustomerHistoryOut.from_orm_custom(h) for h in histories]


# ============================================================================
# CUSTOMER HISTORY & INTERACTION ENDPOINTS
# ============================================================================

@router.get("/interactions", response_model=List[CustomerHistoryOut], summary="List recent interactions")
def list_interactions(
    limit: int = 20,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    histories = crm_service.get_recent_interactions(db, limit=limit)
    return [CustomerHistoryOut.from_orm_custom(h) for h in histories]


@router.post("/interactions", response_model=CustomerHistoryOut, status_code=status.HTTP_201_CREATED, summary="Log an interaction / activity")
def log_interaction(
    history_in: CustomerHistoryCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    interaction = crm_service.create_interaction(db, history_in, current_user.id)
    return CustomerHistoryOut.from_orm_custom(interaction)


@router.get("/followups", response_model=List[CustomerHistoryOut], summary="Get upcoming follow-up tasks")
def get_upcoming_followups(
    limit: int = 20,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    followups = crm_service.get_upcoming_followups(db, limit=limit)
    return [CustomerHistoryOut.from_orm_custom(f) for f in followups]
