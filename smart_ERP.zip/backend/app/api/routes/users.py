from typing import List
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from app.database.session import get_db
from app.models.user import User
from app.models.role import Role
from app.models.permission import Permission
from app.schemas.user import UserOut, UserCreate, UserUpdate, UserRoleAssignRequest
from app.schemas.role import RoleOut
from app.schemas.permission import PermissionOut
from app.services.user_service import get_users, get_user_by_id, create_user, update_user, assign_user_roles
from app.api.deps import get_current_user, require_role

router = APIRouter(prefix="/users", tags=["Users & Access Control"])


@router.get("", response_model=List[UserOut], summary="List users (Admin/Manager)")
def list_users(
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role(["ADMIN", "MANAGER"])),
):
    users = get_users(db, skip=skip, limit=limit)
    return [UserOut.from_orm_custom(u) for u in users]


@router.get("/{user_id}", response_model=UserOut, summary="Get user by ID")
def get_user(
    user_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    # Allow users to view themselves or admins/managers to view any user
    if current_user.id != user_id and "ADMIN" not in current_user.role_names and "MANAGER" not in current_user.role_names:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Access denied")
    user = get_user_by_id(db, user_id)
    if not user:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User not found")
    return UserOut.from_orm_custom(user)


@router.post("", response_model=UserOut, status_code=status.HTTP_201_CREATED, summary="Create user (Admin only)")
def create_new_user(
    user_in: UserCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role(["ADMIN"])),
):
    user = create_user(db, user_in)
    return UserOut.from_orm_custom(user)


@router.put("/{user_id}", response_model=UserOut, summary="Update user (Admin only)")
def update_existing_user(
    user_id: int,
    user_in: UserUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role(["ADMIN"])),
):
    db_user = get_user_by_id(db, user_id)
    if not db_user:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User not found")
    user = update_user(db, db_user, user_in)
    return UserOut.from_orm_custom(user)


@router.post("/{user_id}/roles", response_model=UserOut, summary="Assign roles to user (Admin only)")
def assign_roles(
    user_id: int,
    role_data: UserRoleAssignRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role(["ADMIN"])),
):
    user = assign_user_roles(db, user_id, role_data.role_ids)
    if not user:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User not found")
    return UserOut.from_orm_custom(user)


# Roles and Permissions Read Endpoints
@router.get("/access/roles", response_model=List[RoleOut], summary="List all roles")
def list_roles(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    roles = db.query(Role).all()
    return [RoleOut.from_orm_with_permissions(r) for r in roles]


@router.get("/access/permissions", response_model=List[PermissionOut], summary="List all permissions")
def list_permissions(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    return db.query(Permission).all()
