from fastapi import APIRouter, Depends
from app.api.deps import get_current_user
from app.models.user import User

router = APIRouter(prefix="/sales", tags=["Sales (Member 5 — Upcoming)"])


@router.get("/status", summary="Sales Module Status")
def get_sales_status(current_user: User = Depends(get_current_user)):
    return {
        "module": "Sales & Invoicing",
        "status": "Planned for Phase 2",
        "description": "Quotations, Sales Orders, Invoices, and Payments will be connected here.",
        "version": "0.1.0-alpha",
    }
