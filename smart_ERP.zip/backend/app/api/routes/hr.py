from fastapi import APIRouter, Depends
from app.api.deps import get_current_user
from app.models.user import User

router = APIRouter(prefix="/hr", tags=["HR Management (Member 2 — Upcoming)"])


@router.get("/status", summary="HR Module Status")
def get_hr_status(current_user: User = Depends(get_current_user)):
    return {
        "module": "HR Management",
        "status": "Planned for Phase 2",
        "description": "Employees, Departments, Attendance, Leave Management will be connected here.",
        "version": "0.1.0-alpha",
    }
