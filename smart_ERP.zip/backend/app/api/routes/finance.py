from fastapi import APIRouter, Depends
from app.api.deps import get_current_user
from app.models.user import User

router = APIRouter(prefix="/finance", tags=["Finance & Accounting (Member 6 — Upcoming)"])


@router.get("/status", summary="Finance Module Status")
def get_finance_status(current_user: User = Depends(get_current_user)):
    return {
        "module": "Finance & Accounting",
        "status": "Planned for Phase 2",
        "description": "General Ledger, Expenses, and Financial Transactions will be connected here.",
        "version": "0.1.0-alpha",
    }
