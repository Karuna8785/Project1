from fastapi import APIRouter, Depends
from app.api.deps import get_current_user
from app.models.user import User

router = APIRouter(prefix="/inventory", tags=["Inventory (Member 4 — Upcoming)"])


@router.get("/status", summary="Inventory Module Status")
def get_inventory_status(current_user: User = Depends(get_current_user)):
    return {
        "module": "Inventory Management",
        "status": "Planned for Phase 2",
        "description": "Products, Categories, Warehouses, and Stock Control will be connected here.",
        "version": "0.1.0-alpha",
    }
