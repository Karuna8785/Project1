from fastapi import APIRouter, Depends, Request, status
from sqlalchemy.orm import Session
from app.database.session import get_db
from app.schemas.auth import RegisterRequest, LoginRequest, TokenResponse, UserSummary, PasswordChangeRequest
from app.schemas.user import UserOut
from app.services.auth_service import authenticate_user, register_user
from app.services.audit_service import log_security_event
from app.api.deps import get_current_user, get_client_ip, require_role
from app.models.user import User
from app.core.security import verify_password, get_password_hash

router = APIRouter(prefix="/auth", tags=["Authentication & Security"])


@router.post("/register", response_model=UserSummary, status_code=status.HTTP_201_CREATED, summary="Register a new user")
def register(
    reg_data: RegisterRequest,
    request: Request,
    db: Session = Depends(get_db),
):
    """Register a new user in the SmartERP system with secure validation and password hashing."""
    client_ip = get_client_ip(request)
    user_agent = request.headers.get("User-Agent")
    return register_user(db, reg_data, ip_address=client_ip, user_agent=user_agent)


@router.post("/login", response_model=TokenResponse, summary="Authenticate user and receive JWT token")
def login(
    login_data: LoginRequest,
    request: Request,
    db: Session = Depends(get_db),
):
    """Log in with username or email and password to obtain a JWT Bearer token."""
    client_ip = get_client_ip(request)
    user_agent = request.headers.get("User-Agent")
    return authenticate_user(db, login_data, ip_address=client_ip, user_agent=user_agent)


@router.get("/me", response_model=UserOut, summary="Get current logged-in user profile")
def get_me(
    current_user: User = Depends(get_current_user),
):
    """Return the currently authenticated user's profile, roles, and permissions."""
    return UserOut.from_orm_custom(current_user)


@router.post("/logout", summary="Logout current user and log security audit event")
def logout(
    request: Request,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Log out the current user session and record security audit log."""
    client_ip = get_client_ip(request)
    user_agent = request.headers.get("User-Agent")
    log_security_event(
        db=db,
        action="LOGOUT",
        user_id=current_user.id,
        user_email=current_user.email,
        entity_type="AUTH",
        ip_address=client_ip,
        user_agent=user_agent,
        details={"username": current_user.username, "status": "User logged out successfully"},
    )
    return {"message": "Logged out successfully"}


@router.post("/change-password", summary="Change current user's password")
def change_password(
    pwd_data: PasswordChangeRequest,
    request: Request,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Allow logged in user to update their password securely."""
    if not verify_password(pwd_data.old_password, current_user.hashed_password):
        log_security_event(
            db=db,
            action="PASSWORD_CHANGE_FAILED_WRONG_OLD_PWD",
            user_id=current_user.id,
            user_email=current_user.email,
            entity_type="AUTH",
            ip_address=get_client_ip(request),
        )
        return {"error": "Current password does not match."}
    
    current_user.hashed_password = get_password_hash(pwd_data.new_password)
    db.commit()

    log_security_event(
        db=db,
        action="PASSWORD_CHANGE_SUCCESS",
        user_id=current_user.id,
        user_email=current_user.email,
        entity_type="AUTH",
        ip_address=get_client_ip(request),
    )
    return {"message": "Password updated successfully"}


# Security testing endpoints
@router.get("/protected", summary="Sample protected endpoint for testing authentication")
def protected_test(current_user: User = Depends(get_current_user)):
    return {
        "message": "Authentication verification successful!",
        "user": current_user.username,
        "role": current_user.primary_role,
    }


@router.get("/admin-only", summary="Sample admin-only endpoint for testing RBAC")
def admin_only_test(current_user: User = Depends(require_role(["ADMIN"]))):
    return {
        "message": "Welcome Administrator! RBAC validation successful.",
        "admin_user": current_user.username,
    }
