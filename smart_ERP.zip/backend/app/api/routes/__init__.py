from fastapi import APIRouter
from app.api.routes import (
    auth,
    users,
    audit,
    crm,
    hr,
    inventory,
    sales,
    procurement,
    finance,
    reports,
)

api_router = APIRouter()

# Active functional modules
api_router.include_router(auth.router)
api_router.include_router(users.router)
api_router.include_router(audit.router)
api_router.include_router(crm.router)

# Architecture placeholders for upcoming modules
api_router.include_router(hr.router)
api_router.include_router(inventory.router)
api_router.include_router(sales.router)
api_router.include_router(procurement.router)
api_router.include_router(finance.router)
api_router.include_router(reports.router)
