from typing import List, Optional
from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from app.database.session import get_db
from app.models.user import User
from app.schemas.audit_log import AuditLogOut
from app.services.audit_service import get_audit_logs
from app.api.deps import get_current_user, require_role

router = APIRouter(prefix="/audit", tags=["Security Audit Logs"])


@router.get("/logs", response_model=List[AuditLogOut], summary="List security audit logs (Admin/Manager)")
def view_audit_logs(
    skip: int = 0,
    limit: int = 100,
    action: Optional[str] = Query(None, description="Filter by action code"),
    user_id: Optional[int] = Query(None, description="Filter by user id"),
    entity_type: Optional[str] = Query(None, description="Filter by entity type"),
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role(["ADMIN", "MANAGER"])),
):
    return get_audit_logs(
        db=db,
        skip=skip,
        limit=limit,
        user_id=user_id,
        action=action,
        entity_type=entity_type,
    )


@router.get("/my-logs", response_model=List[AuditLogOut], summary="View current user's security events")
def view_my_audit_logs(
    skip: int = 0,
    limit: int = 50,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    return get_audit_logs(
        db=db,
        skip=skip,
        limit=limit,
        user_id=current_user.id,
    )
