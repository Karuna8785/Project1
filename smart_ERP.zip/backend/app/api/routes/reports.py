from fastapi import APIRouter, Depends
from app.api.deps import get_current_user
from app.models.user import User

router = APIRouter(prefix="/reports", tags=["Reports & Analytics (Member 7 — Upcoming)"])


@router.get("/status", summary="Reports Module Status")
def get_reports_status(current_user: User = Depends(get_current_user)):
    return {
        "module": "Reports & Analytics",
        "status": "Planned for Phase 2",
        "description": "Cross-module BI reporting, PDF export, and custom charts will be connected here.",
        "version": "0.1.0-alpha",
    }
