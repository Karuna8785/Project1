from datetime import datetime, timezone
from sqlalchemy import Column, Integer, String, Text, Numeric, DateTime, ForeignKey, Enum
from sqlalchemy.orm import relationship
from app.database.session import Base


class Customer(Base):
    __tablename__ = "customers"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    customer_code = Column(String(50), unique=True, index=True, nullable=False)
    name = Column(String(150), nullable=False, index=True)
    company_name = Column(String(150), nullable=True)
    email = Column(String(255), unique=True, index=True, nullable=False)
    phone = Column(String(50), nullable=True)
    website = Column(String(255), nullable=True)
    industry = Column(String(100), nullable=True, default="Technology")
    customer_type = Column(String(50), default="INDIVIDUAL", nullable=False)  # INDIVIDUAL, CORPORATE, ENTERPRISE, SMB
    status = Column(String(50), default="ACTIVE", nullable=False, index=True)  # ACTIVE, INACTIVE, PROSPECT, BLOCKED
    
    # Address
    address_line1 = Column(String(255), nullable=True)
    address_line2 = Column(String(255), nullable=True)
    city = Column(String(100), nullable=True)
    state = Column(String(100), nullable=True)
    postal_code = Column(String(20), nullable=True)
    country = Column(String(100), nullable=True, default="United States")

    # Financial / Business details
    annual_revenue = Column(Numeric(15, 2), nullable=True, default=0.00)
    credit_limit = Column(Numeric(15, 2), nullable=True, default=0.00)
    notes = Column(Text, nullable=True)

    # Ownership
    assigned_to_id = Column(Integer, ForeignKey("users.id", ondelete="SET NULL"), nullable=True, index=True)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc), nullable=False)
    updated_at = Column(DateTime, default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc), nullable=False)

    assigned_to = relationship("User", back_populates="assigned_customers")
    interactions = relationship("CustomerHistory", back_populates="customer", cascade="all, delete-orphan", order_by="desc(CustomerHistory.created_at)")
    leads = relationship("Lead", back_populates="converted_customer")

    def __repr__(self):
        return f"<Customer code={self.customer_code} name={self.name}>"
