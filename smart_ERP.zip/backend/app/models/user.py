from datetime import datetime, timezone
from sqlalchemy import Column, Integer, String, Boolean, DateTime
from sqlalchemy.orm import relationship
from app.database.session import Base


class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    full_name = Column(String(150), nullable=False)
    email = Column(String(255), unique=True, index=True, nullable=False)
    username = Column(String(50), unique=True, index=True, nullable=False)
    hashed_password = Column(String(255), nullable=False)
    is_active = Column(Boolean, default=True, nullable=False)
    is_superuser = Column(Boolean, default=False, nullable=False)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc), nullable=False)
    updated_at = Column(DateTime, default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc), nullable=False)

    roles = relationship("UserRole", back_populates="user", cascade="all, delete-orphan")
    audit_logs = relationship("AuditLog", back_populates="user", cascade="all, delete-orphan")
    assigned_customers = relationship("Customer", back_populates="assigned_to")
    assigned_leads = relationship("Lead", back_populates="assigned_to")
    interactions = relationship("CustomerHistory", back_populates="user")

    @property
    def role_names(self):
        return [ur.role.name for ur in self.roles if ur.role]

    @property
    def primary_role(self):
        names = self.role_names
        if "ADMIN" in names:
            return "ADMIN"
        if "MANAGER" in names:
            return "MANAGER"
        if names:
            return names[0]
        return "EMPLOYEE"

    @property
    def permissions(self):
        perms = set()
        for ur in self.roles:
            if ur.role and ur.role.permissions:
                for rp in ur.role.permissions:
                    if rp.permission:
                        perms.add(rp.permission.code)
        return list(perms)

    def __repr__(self):
        return f"<User username={self.username} email={self.email}>"
