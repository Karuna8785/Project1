from datetime import datetime, timezone
from sqlalchemy import Column, Integer, String, Text, DateTime, ForeignKey
from sqlalchemy.orm import relationship
from app.database.session import Base


class CustomerHistory(Base):
    __tablename__ = "customer_history"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    customer_id = Column(Integer, ForeignKey("customers.id", ondelete="CASCADE"), nullable=True, index=True)
    lead_id = Column(Integer, ForeignKey("leads.id", ondelete="CASCADE"), nullable=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="SET NULL"), nullable=True, index=True)

    interaction_type = Column(String(50), nullable=False)  # CALL, EMAIL, MEETING, NOTE, TASK, STATUS_CHANGE, DEAL_UPDATE
    title = Column(String(200), nullable=False)
    notes = Column(Text, nullable=True)
    outcome = Column(String(100), nullable=True)  # COMPLETED, FOLLOW_UP_REQUIRED, PENDING, CANCELLED
    
    interaction_date = Column(DateTime, default=lambda: datetime.now(timezone.utc), nullable=False)
    next_follow_up = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc), nullable=False)

    customer = relationship("Customer", back_populates="interactions")
    lead = relationship("Lead", back_populates="interactions")
    user = relationship("User", back_populates="interactions")

    def __repr__(self):
        return f"<CustomerHistory type={self.interaction_type} title={self.title}>"
