from datetime import datetime, timezone
from sqlalchemy import Column, Integer, String, Text, Numeric, DateTime, ForeignKey
from sqlalchemy.orm import relationship
from app.database.session import Base


class Lead(Base):
    __tablename__ = "leads"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    first_name = Column(String(100), nullable=False)
    last_name = Column(String(100), nullable=False)
    email = Column(String(255), unique=True, index=True, nullable=False)
    phone = Column(String(50), nullable=True)
    company = Column(String(150), nullable=True)
    title = Column(String(100), nullable=True)
    
    # Lead tracking
    lead_source = Column(String(50), default="WEBSITE", nullable=False)  # WEBSITE, REFERRAL, COLD_CALL, CAMPAIGN, PARTNER, OTHER
    lead_status = Column(String(50), default="NEW", nullable=False, index=True)  # NEW, CONTACTED, QUALIFIED, PROPOSAL_SENT, NEGOTIATION, WON, LOST
    lead_score = Column(Integer, default=50, nullable=False)  # 0 to 100
    estimated_value = Column(Numeric(15, 2), default=0.00, nullable=False)
    notes = Column(Text, nullable=True)

    # Assignment & Conversion
    assigned_to_id = Column(Integer, ForeignKey("users.id", ondelete="SET NULL"), nullable=True, index=True)
    converted_customer_id = Column(Integer, ForeignKey("customers.id", ondelete="SET NULL"), nullable=True, index=True)
    converted_at = Column(DateTime, nullable=True)

    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc), nullable=False)
    updated_at = Column(DateTime, default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc), nullable=False)

    assigned_to = relationship("User", back_populates="assigned_leads")
    converted_customer = relationship("Customer", back_populates="leads")
    interactions = relationship("CustomerHistory", back_populates="lead", cascade="all, delete-orphan", order_by="desc(CustomerHistory.created_at)")

    @property
    def full_name(self):
        return f"{self.first_name} {self.last_name}"

    def __repr__(self):
        return f"<Lead name={self.full_name} status={self.lead_status}>"
